"""
FastAPI webhook receiver for TradingView alerts.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field

from ..config import Settings, get_settings
from ..models.signal import Signal
from ..utils.validation import SignalValidator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhook", tags=["webhook"])


class WebhookPayload(BaseModel):
    """Expected webhook payload from TradingView."""
    signal: str = Field(..., description="BUY or SELL")
    symbol: str = Field(default="BTCUSD")
    time: Optional[str] = Field(default=None, description="ISO timestamp")
    close: float = Field(..., description="Candle close price")
    adx: float = Field(..., description="ADX strength value")
    braid_color: str = Field(..., description="green or red")
    bar_close: bool = Field(default=True)
    tf: str = Field(default="15m")
    extra: Optional[Dict[str, Any]] = None


class WebhookResponse(BaseModel):
    """Response from webhook endpoint."""
    success: bool
    message: str
    signal_id: Optional[str] = None
    warnings: list = []


# Dependency to get shared services
_validator: Optional[SignalValidator] = None
_trade_executor = None


def get_validator() -> SignalValidator:
    """Get signal validator instance."""
    global _validator
    if _validator is None:
        _validator = SignalValidator(get_settings())
    return _validator


def set_trade_executor(executor):
    """Set the trade executor for processing signals."""
    global _trade_executor
    _trade_executor = executor


@router.post("/tradingview", response_model=WebhookResponse)
async def receive_tradingview_alert(
    request: Request,
    background_tasks: BackgroundTasks,
    x_signature: Optional[str] = Header(None, alias="X-Signature"),
    settings: Settings = Depends(get_settings)
):
    """
    Receive and process TradingView webhook alerts.
    
    Headers:
        X-Signature: HMAC-SHA256 signature of request body
    
    Body:
        TradingView alert JSON payload
    """
    # Get raw body for signature verification
    raw_body = await request.body()
    
    try:
        payload = json.loads(raw_body)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON payload: {e}")
        raise HTTPException(status_code=400, detail="Invalid JSON payload")
    
    logger.info(f"Received webhook: {payload.get('signal')} @ {payload.get('close')}")
    
    # Get validator
    validator = get_validator()
    
    # Get current trades today from database (simplified - would use real DB)
    from ..services.database import Database
    db = Database()
    current_trades_today = db.get_daily_trade_count()
    
    # Validate signal
    validation_result = validator.validate_signal(
        payload=payload,
        raw_body=raw_body,
        signature=x_signature,
        current_trades_today=current_trades_today
    )
    
    if not validation_result.is_valid:
        logger.warning(f"Signal rejected: {validation_result.rejection_reason}")
        return WebhookResponse(
            success=False,
            message=validation_result.rejection_reason or "Signal validation failed",
            warnings=validation_result.warnings
        )
    
    signal = validation_result.signal
    
    # Process signal in background if executor is set
    if _trade_executor:
        background_tasks.add_task(process_signal_async, signal)
        return WebhookResponse(
            success=True,
            message="Signal accepted, processing in background",
            signal_id=signal.unique_id,
            warnings=validation_result.warnings
        )
    else:
        # Just validate and acknowledge
        return WebhookResponse(
            success=True,
            message="Signal validated (executor not configured)",
            signal_id=signal.unique_id,
            warnings=validation_result.warnings
        )


async def process_signal_async(signal: Signal):
    """Process signal asynchronously."""
    if _trade_executor:
        try:
            result = await _trade_executor.process_signal(signal)
            if result.success:
                logger.info(f"Signal processed successfully: {signal.unique_id}")
            else:
                logger.error(f"Signal processing failed: {result.error_message}")
        except Exception as e:
            logger.error(f"Error processing signal: {e}")


@router.post("/test", response_model=WebhookResponse)
async def test_webhook(
    payload: WebhookPayload,
    settings: Settings = Depends(get_settings)
):
    """
    Test endpoint to validate webhook payload format.
    Does not execute trades.
    """
    validator = get_validator()
    
    validation_result = validator.validate_signal(
        payload=payload.model_dump(),
        current_trades_today=0
    )
    
    return WebhookResponse(
        success=validation_result.is_valid,
        message="Test validation complete" if validation_result.is_valid else validation_result.rejection_reason,
        signal_id=validation_result.signal.unique_id if validation_result.signal else None,
        warnings=validation_result.warnings
    )


@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

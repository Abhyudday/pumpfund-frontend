"""
FastAPI application setup.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ..config import Settings, get_settings
from ..connectors.manager import ExchangeManager
from ..services.database import Database
from ..services.notifications import NotificationService
from ..services.trade_executor import TradeExecutor
from ..utils.logging import setup_logging
from .admin import router as admin_router, set_database
from .webhook import router as webhook_router, set_trade_executor

logger = logging.getLogger(__name__)

# Global instances
_exchange_manager: Optional[ExchangeManager] = None
_trade_executor: Optional[TradeExecutor] = None
_database: Optional[Database] = None
_notifications: Optional[NotificationService] = None
_monitoring_task: Optional[asyncio.Task] = None


async def start_oco_monitoring():
    """Background task to monitor OCO orders."""
    global _trade_executor
    
    while True:
        try:
            if _trade_executor:
                await _trade_executor.monitor_open_trades()
        except Exception as e:
            logger.error(f"OCO monitoring error: {e}")
        
        await asyncio.sleep(30)  # Check every 30 seconds


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    global _exchange_manager, _trade_executor, _database, _notifications, _monitoring_task
    
    settings = get_settings()
    
    # Setup logging
    setup_logging(
        log_level=settings.log_level,
        log_file=settings.log_file,
        json_format=True
    )
    
    logger.info("Starting Trading Bot API...")
    logger.info(f"Mode: {settings.mode.value}, Paper: {settings.paper_trading}")
    
    # Initialize database
    _database = Database()
    set_database(_database)
    
    # Initialize notifications
    _notifications = NotificationService(settings)
    
    # Initialize exchange manager (only for live mode or if needed)
    if not settings.paper_trading:
        try:
            _exchange_manager = ExchangeManager(settings)
            await _exchange_manager.initialize()
            logger.info("Exchange connections established")
        except Exception as e:
            logger.error(f"Failed to initialize exchanges: {e}")
            _exchange_manager = None
    
    # Initialize trade executor
    if _exchange_manager:
        _trade_executor = TradeExecutor(
            settings=settings,
            exchange_manager=_exchange_manager,
            database=_database,
            notifications=_notifications
        )
        set_trade_executor(_trade_executor)
        
        # Start OCO monitoring
        _monitoring_task = asyncio.create_task(start_oco_monitoring())
        logger.info("OCO monitoring started")
    
    logger.info("Trading Bot API ready")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Trading Bot API...")
    
    if _monitoring_task:
        _monitoring_task.cancel()
        try:
            await _monitoring_task
        except asyncio.CancelledError:
            pass
    
    if _exchange_manager:
        await _exchange_manager.close()
    
    if _notifications:
        await _notifications.close()
    
    logger.info("Trading Bot API shutdown complete")


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title="Trading Bot API",
        description="TradingView webhook receiver and trading bot",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include routers
    app.include_router(webhook_router)
    app.include_router(admin_router)
    
    @app.get("/")
    async def root():
        """Root endpoint."""
        settings = get_settings()
        return {
            "name": "Trading Bot API",
            "version": "1.0.0",
            "mode": settings.mode.value,
            "paper_trading": settings.paper_trading,
            "status": "running"
        }
    
    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "healthy"}
    
    return app


# Application instance
app = create_app()

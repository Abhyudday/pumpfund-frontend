"""
Admin API endpoints for bot management.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from ..config import Settings, get_settings
from ..services.database import Database

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin"])

# Shared database instance
_db: Optional[Database] = None


def get_database() -> Database:
    """Get database instance."""
    global _db
    if _db is None:
        _db = Database()
    return _db


def set_database(db: Database):
    """Set database instance."""
    global _db
    _db = db


class BotStatusResponse(BaseModel):
    """Bot status response."""
    mode: str
    paper_trading: bool
    open_trades: int
    trades_today: int
    max_trades_per_day: int
    risk_locked_to_1pct: bool
    statistics: Dict[str, Any]


class TradeResponse(BaseModel):
    """Trade response model."""
    id: str
    exchange: str
    symbol: str
    direction: str
    status: str
    entry_price: float
    entry_amount: float
    exit_price: Optional[float]
    realized_pnl: float
    realized_pnl_pct: float
    paper_trade: bool
    created_at: str


class ConfigUpdateRequest(BaseModel):
    """Configuration update request."""
    paper_trading: Optional[bool] = None
    mode: Optional[str] = None


@router.get("/status", response_model=BotStatusResponse)
async def get_bot_status(
    settings: Settings = Depends(get_settings),
    db: Database = Depends(get_database)
):
    """Get current bot status."""
    open_trades = db.get_open_trades()
    trades_today = db.get_daily_trade_count()
    stats = db.get_trade_statistics()
    
    return BotStatusResponse(
        mode=settings.mode.value,
        paper_trading=settings.paper_trading,
        open_trades=len(open_trades),
        trades_today=trades_today,
        max_trades_per_day=settings.trading_window.max_trades_per_day,
        risk_locked_to_1pct=db.is_risk_locked(),
        statistics=stats
    )


@router.get("/trades", response_model=List[TradeResponse])
async def get_trades(
    limit: int = Query(default=20, le=100),
    status: Optional[str] = Query(default=None),
    db: Database = Depends(get_database)
):
    """Get recent trades."""
    if status:
        trades = db.get_trades_by_status(status)[:limit]
    else:
        trades = db.get_recent_trades(limit)
    
    return [
        TradeResponse(
            id=t.id,
            exchange=t.exchange,
            symbol=t.symbol,
            direction=t.direction.value,
            status=t.status if isinstance(t.status, str) else t.status.value,
            entry_price=t.entry_price,
            entry_amount=t.entry_amount,
            exit_price=t.exit_price,
            realized_pnl=t.realized_pnl,
            realized_pnl_pct=t.realized_pnl_pct,
            paper_trade=t.paper_trade,
            created_at=t.created_at.isoformat()
        )
        for t in trades
    ]


@router.get("/trades/{trade_id}")
async def get_trade(
    trade_id: str,
    db: Database = Depends(get_database)
):
    """Get trade by ID."""
    trade = db.get_trade(trade_id)
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    return trade.to_dict()


@router.get("/statistics")
async def get_statistics(
    start_date: Optional[str] = Query(default=None),
    end_date: Optional[str] = Query(default=None),
    db: Database = Depends(get_database)
):
    """Get trade statistics."""
    start = date.fromisoformat(start_date) if start_date else None
    end = date.fromisoformat(end_date) if end_date else None
    
    return db.get_trade_statistics(start, end)


@router.post("/config")
async def update_config(
    request: ConfigUpdateRequest,
    settings: Settings = Depends(get_settings)
):
    """
    Update bot configuration.
    Note: Some changes require restart to take effect.
    """
    changes = []
    
    if request.paper_trading is not None:
        old_value = settings.paper_trading
        settings.paper_trading = request.paper_trading
        changes.append(f"paper_trading: {old_value} -> {request.paper_trading}")
    
    if request.mode is not None:
        from ..config import ExecutionMode
        if request.mode not in [m.value for m in ExecutionMode]:
            raise HTTPException(status_code=400, detail=f"Invalid mode: {request.mode}")
        old_value = settings.mode.value
        settings.mode = ExecutionMode(request.mode)
        changes.append(f"mode: {old_value} -> {request.mode}")
    
    return {
        "success": True,
        "changes": changes,
        "message": "Configuration updated. Some changes may require restart."
    }


@router.get("/equity")
async def get_equity(settings: Settings = Depends(get_settings)):
    """
    Get account equity summary.
    In paper mode, returns simulated values.
    """
    if settings.paper_trading:
        return {
            "paper_mode": True,
            "total_equity": 20000.0,
            "breakdown": {
                "coinbase": 10000.0,
                "kraken": 10000.0
            },
            "risk_per_trade": "2% (or 1% if locked)"
        }
    
    # Would need exchange manager to fetch real equity
    return {
        "paper_mode": False,
        "message": "Connect via main app for real equity data"
    }


@router.post("/reset-daily-counter")
async def reset_daily_counter(db: Database = Depends(get_database)):
    """Reset daily trade counter (admin only)."""
    today = datetime.utcnow().date().isoformat()
    
    with db._get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM daily_trade_counters WHERE date = ?",
            (today,)
        )
    
    return {"success": True, "message": "Daily counter reset"}


@router.get("/position-calculator")
async def calculate_position(
    equity: float = Query(..., description="Account equity in USD"),
    entry_price: float = Query(..., description="Entry price"),
    risk_locked: bool = Query(default=False, description="Is risk locked to 1%?"),
    settings: Settings = Depends(get_settings)
):
    """Calculate position size for given parameters."""
    from ..utils.risk import RiskCalculator
    
    calculator = RiskCalculator(settings)
    if risk_locked:
        calculator.set_risk_locked(True)
    
    result = calculator.calculate_position_size(
        equity=equity,
        entry_price=entry_price,
        is_long=True
    )
    
    return {
        "equity": equity,
        "entry_price": entry_price,
        "risk_percentage": result.risk_percentage * 100,
        "risk_amount": result.risk_amount,
        "position_size": result.position_size,
        "position_value": result.position_value,
        "stop_loss_price": result.stop_loss_price,
        "take_profit_price": result.take_profit_price,
        "is_valid": result.is_valid,
        "rejection_reason": result.rejection_reason
    }

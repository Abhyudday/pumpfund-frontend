"""
Backtesting engine for strategy evaluation.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..config import Settings
from ..models.trade import ExitReason, Trade, TradeDirection, TradeStatus
from .data import OHLCVCandle, OHLCVData
from .metrics import BacktestMetrics, calculate_metrics, export_metrics_csv

logger = logging.getLogger(__name__)


@dataclass
class BacktestConfig:
    """Configuration for backtest run."""
    initial_equity: float = 10000.0
    stop_loss_pct: float = 6.0
    take_profit_pct: float = 15.0
    risk_pct: float = 2.0
    max_trades_per_day: int = 2
    blocked_start_hour: int = 22
    blocked_end_hour: int = 0
    adx_baseline: float = 20.0
    max_extension_pct: float = 1.5
    commission_pct: float = 0.1  # 0.1% per trade
    slippage_pct: float = 0.05  # 0.05% slippage


@dataclass
class BacktestPosition:
    """Open position during backtest."""
    trade: Trade
    stop_loss: float
    take_profit: float
    entry_bar: int


@dataclass
class SignalResult:
    """Result of signal generation."""
    signal: Optional[str] = None  # "BUY", "SELL", or None
    adx: float = 0.0
    braid_color: str = "gray"
    strength_ok: bool = False


class Backtester:
    """
    Backtesting engine that replays historical data and simulates trades.
    
    Implements exact trading rules:
    - Entry on candle close
    - 6% SL, 15% TP
    - Risk-based position sizing
    - Blocked trading window
    - Max 2 trades per day
    """
    
    def __init__(self, config: Optional[BacktestConfig] = None):
        self.config = config or BacktestConfig()
        self.positions: List[BacktestPosition] = []
        self.closed_trades: List[Trade] = []
        self.equity = self.config.initial_equity
        self.equity_curve: List[float] = []
        self.daily_trade_count: Dict[str, int] = {}
        
        # Signal generator (can be customized)
        self._signal_generator: Optional[Callable] = None
    
    def set_signal_generator(self, generator: Callable[[OHLCVData, int], SignalResult]):
        """
        Set custom signal generator function.
        
        The function receives (data, current_bar_index) and returns SignalResult.
        """
        self._signal_generator = generator
    
    def _default_signal_generator(self, data: OHLCVData, idx: int) -> SignalResult:
        """
        Default signal generator using simple moving average crossover.
        
        In practice, this would implement the Braid Filter logic.
        For backtesting, we simulate signals based on price action.
        """
        if idx < 20:  # Need enough history
            return SignalResult()
        
        # Simple trend detection (placeholder for actual Braid Filter)
        closes = [data[i].close for i in range(max(0, idx - 20), idx + 1)]
        
        ma_fast = sum(closes[-5:]) / 5
        ma_slow = sum(closes[-14:]) / 14
        ma_trend = sum(closes[-20:]) / 20
        
        # Simulate ADX (volatility proxy)
        recent_range = max(closes[-14:]) - min(closes[-14:])
        avg_price = sum(closes[-14:]) / 14
        adx_proxy = (recent_range / avg_price) * 100 * 5  # Scale to ADX-like values
        
        strength_ok = adx_proxy > self.config.adx_baseline
        
        current_close = data[idx].close
        
        # Determine braid alignment
        if ma_fast > ma_slow > ma_trend:
            braid_color = "green"
        elif ma_fast < ma_slow < ma_trend:
            braid_color = "red"
        else:
            braid_color = "gray"
        
        # Check extension from braid (using MA as proxy)
        braid_mid = (ma_fast + ma_slow + ma_trend) / 3
        extension_pct = abs(current_close - braid_mid) / braid_mid * 100
        
        not_extended = extension_pct <= self.config.max_extension_pct
        
        signal = None
        
        # BUY conditions
        if braid_color == "green" and strength_ok and current_close > max(ma_fast, ma_slow, ma_trend) and not_extended:
            signal = "BUY"
        
        # SELL conditions
        elif braid_color == "red" and strength_ok and current_close < min(ma_fast, ma_slow, ma_trend) and not_extended:
            signal = "SELL"
        
        return SignalResult(
            signal=signal,
            adx=adx_proxy,
            braid_color=braid_color,
            strength_ok=strength_ok
        )
    
    def _is_blocked_window(self, timestamp: datetime) -> bool:
        """Check if timestamp is in blocked trading window."""
        hour = timestamp.hour
        
        if self.config.blocked_start_hour > self.config.blocked_end_hour:
            # Overnight window (e.g., 22:00 to 00:00)
            return hour >= self.config.blocked_start_hour or hour < self.config.blocked_end_hour
        else:
            return self.config.blocked_start_hour <= hour < self.config.blocked_end_hour
    
    def _can_trade_today(self, timestamp: datetime) -> bool:
        """Check if daily trade limit allows trading."""
        date_key = timestamp.strftime("%Y-%m-%d")
        count = self.daily_trade_count.get(date_key, 0)
        return count < self.config.max_trades_per_day
    
    def _increment_daily_count(self, timestamp: datetime) -> None:
        """Increment daily trade counter."""
        date_key = timestamp.strftime("%Y-%m-%d")
        self.daily_trade_count[date_key] = self.daily_trade_count.get(date_key, 0) + 1
    
    def _calculate_position_size(self, entry_price: float) -> float:
        """Calculate position size based on risk."""
        risk_amount = self.equity * (self.config.risk_pct / 100)
        stop_distance = entry_price * (self.config.stop_loss_pct / 100)
        position_size = risk_amount / stop_distance
        return position_size
    
    def _check_exits(self, candle: OHLCVCandle, bar_idx: int) -> List[Trade]:
        """Check all open positions for SL/TP hits."""
        closed = []
        remaining = []
        
        for pos in self.positions:
            triggered = False
            exit_price = None
            exit_reason = None
            
            if pos.trade.direction == TradeDirection.LONG:
                # Check stop loss (uses low)
                if candle.low <= pos.stop_loss:
                    triggered = True
                    exit_price = pos.stop_loss
                    exit_reason = ExitReason.STOP_LOSS
                # Check take profit (uses high)
                elif candle.high >= pos.take_profit:
                    triggered = True
                    exit_price = pos.take_profit
                    exit_reason = ExitReason.TAKE_PROFIT
            
            else:  # SHORT
                # Check stop loss (uses high)
                if candle.high >= pos.stop_loss:
                    triggered = True
                    exit_price = pos.stop_loss
                    exit_reason = ExitReason.STOP_LOSS
                # Check take profit (uses low)
                elif candle.low <= pos.take_profit:
                    triggered = True
                    exit_price = pos.take_profit
                    exit_reason = ExitReason.TAKE_PROFIT
            
            if triggered:
                # Apply slippage (unfavorable direction)
                if exit_reason == ExitReason.STOP_LOSS:
                    if pos.trade.direction == TradeDirection.LONG:
                        exit_price *= (1 - self.config.slippage_pct / 100)
                    else:
                        exit_price *= (1 + self.config.slippage_pct / 100)
                
                # Calculate P&L
                exit_value = exit_price * pos.trade.entry_amount
                commission = exit_value * (self.config.commission_pct / 100)
                
                pos.trade.exit_price = exit_price
                pos.trade.exit_amount = pos.trade.entry_amount
                pos.trade.exit_value = exit_value
                pos.trade.exit_time = candle.timestamp
                pos.trade.exit_reason = exit_reason
                pos.trade.exit_fee = commission
                pos.trade.status = TradeStatus.CLOSED
                pos.trade.calculate_pnl()
                
                self.equity += pos.trade.realized_pnl
                closed.append(pos.trade)
            else:
                remaining.append(pos)
        
        self.positions = remaining
        return closed
    
    def _open_position(
        self,
        candle: OHLCVCandle,
        direction: TradeDirection,
        bar_idx: int
    ) -> Trade:
        """Open a new position."""
        # Entry at close with slippage
        if direction == TradeDirection.LONG:
            entry_price = candle.close * (1 + self.config.slippage_pct / 100)
        else:
            entry_price = candle.close * (1 - self.config.slippage_pct / 100)
        
        position_size = self._calculate_position_size(entry_price)
        entry_value = entry_price * position_size
        commission = entry_value * (self.config.commission_pct / 100)
        
        # Calculate SL/TP levels
        if direction == TradeDirection.LONG:
            stop_loss = entry_price * (1 - self.config.stop_loss_pct / 100)
            take_profit = entry_price * (1 + self.config.take_profit_pct / 100)
        else:
            stop_loss = entry_price * (1 + self.config.stop_loss_pct / 100)
            take_profit = entry_price * (1 - self.config.take_profit_pct / 100)
        
        trade = Trade(
            exchange="backtest",
            symbol="BTC/USD",
            direction=direction,
            status=TradeStatus.OPEN,
            entry_price=entry_price,
            entry_amount=position_size,
            entry_value=entry_value,
            entry_time=candle.timestamp,
            entry_fee=commission,
            stop_loss_price=stop_loss,
            take_profit_price=take_profit,
            paper_trade=True
        )
        
        self.equity -= commission  # Entry commission
        
        position = BacktestPosition(
            trade=trade,
            stop_loss=stop_loss,
            take_profit=take_profit,
            entry_bar=bar_idx
        )
        
        self.positions.append(position)
        self._increment_daily_count(candle.timestamp)
        
        logger.debug(
            f"Opened {direction.value} @ ${entry_price:.2f}, "
            f"SL=${stop_loss:.2f}, TP=${take_profit:.2f}"
        )
        
        return trade
    
    def run(self, data: OHLCVData) -> Tuple[BacktestMetrics, List[Trade]]:
        """
        Run backtest on historical data.
        
        Args:
            data: OHLCV candle data
        
        Returns:
            Tuple of (metrics, list of trades)
        """
        logger.info(f"Starting backtest: {len(data)} candles, ${self.config.initial_equity:,.2f} initial equity")
        
        # Reset state
        self.positions = []
        self.closed_trades = []
        self.equity = self.config.initial_equity
        self.equity_curve = [self.equity]
        self.daily_trade_count = {}
        
        signal_gen = self._signal_generator or self._default_signal_generator
        
        for i, candle in enumerate(data.candles):
            # First check exits on current candle
            closed = self._check_exits(candle, i)
            self.closed_trades.extend(closed)
            
            # Record equity after exits
            self.equity_curve.append(self.equity)
            
            # Check for new entry signals (only if no open position)
            if not self.positions:
                # Check blocked window
                if self._is_blocked_window(candle.timestamp):
                    continue
                
                # Check daily limit
                if not self._can_trade_today(candle.timestamp):
                    continue
                
                # Generate signal
                result = signal_gen(data, i)
                
                if result.signal == "BUY":
                    self._open_position(candle, TradeDirection.LONG, i)
                elif result.signal == "SELL":
                    self._open_position(candle, TradeDirection.SHORT, i)
        
        # Close any remaining positions at last price
        if self.positions and data.candles:
            last_candle = data.candles[-1]
            for pos in self.positions:
                pos.trade.exit_price = last_candle.close
                pos.trade.exit_amount = pos.trade.entry_amount
                pos.trade.exit_value = last_candle.close * pos.trade.entry_amount
                pos.trade.exit_time = last_candle.timestamp
                pos.trade.exit_reason = ExitReason.SYSTEM
                pos.trade.status = TradeStatus.CLOSED
                pos.trade.calculate_pnl()
                self.equity += pos.trade.realized_pnl
                self.closed_trades.append(pos.trade)
        
        # Calculate metrics
        metrics = calculate_metrics(
            trades=self.closed_trades,
            initial_equity=self.config.initial_equity
        )
        
        logger.info(f"Backtest complete: {len(self.closed_trades)} trades, "
                   f"P&L: ${metrics.total_pnl:,.2f} ({metrics.total_pnl_pct:.2f}%)")
        
        return metrics, self.closed_trades
    
    def export_results(self, filepath: str, metrics: BacktestMetrics) -> None:
        """Export backtest results to CSV."""
        export_metrics_csv(metrics, self.closed_trades, filepath)
        logger.info(f"Results exported to {filepath}")


def run_parameter_optimization(
    data: OHLCVData,
    param_ranges: Dict[str, List[Any]],
    initial_equity: float = 10000.0
) -> List[Tuple[Dict[str, Any], BacktestMetrics]]:
    """
    Run parameter optimization over multiple backtest configurations.
    
    Args:
        data: Historical OHLCV data
        param_ranges: Dict of parameter names to lists of values to test
        initial_equity: Starting equity
    
    Returns:
        List of (params, metrics) sorted by Sharpe ratio
    """
    import itertools
    
    results = []
    
    # Generate all parameter combinations
    param_names = list(param_ranges.keys())
    param_values = list(param_ranges.values())
    
    for values in itertools.product(*param_values):
        params = dict(zip(param_names, values))
        
        config = BacktestConfig(
            initial_equity=initial_equity,
            **params
        )
        
        backtester = Backtester(config)
        metrics, _ = backtester.run(data)
        
        results.append((params, metrics))
        
        logger.info(f"Params: {params} -> Sharpe: {metrics.sharpe_ratio:.2f}, "
                   f"Total Return: {metrics.total_return_pct:.2f}%")
    
    # Sort by Sharpe ratio
    results.sort(key=lambda x: x[1].sharpe_ratio, reverse=True)
    
    return results

"""
Historical data loading and management for backtesting.
"""
from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import ccxt

logger = logging.getLogger(__name__)


@dataclass
class OHLCVCandle:
    """Single OHLCV candle."""
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    
    @classmethod
    def from_ccxt(cls, data: List) -> "OHLCVCandle":
        """Create from CCXT OHLCV data [timestamp, O, H, L, C, V]."""
        return cls(
            timestamp=datetime.fromtimestamp(data[0] / 1000),
            open=float(data[1]),
            high=float(data[2]),
            low=float(data[3]),
            close=float(data[4]),
            volume=float(data[5])
        )
    
    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume
        }


@dataclass
class OHLCVData:
    """Container for OHLCV data series."""
    symbol: str
    timeframe: str
    candles: List[OHLCVCandle]
    
    def __len__(self) -> int:
        return len(self.candles)
    
    def __getitem__(self, idx: int) -> OHLCVCandle:
        return self.candles[idx]
    
    def __iter__(self):
        return iter(self.candles)
    
    @property
    def start_time(self) -> Optional[datetime]:
        return self.candles[0].timestamp if self.candles else None
    
    @property
    def end_time(self) -> Optional[datetime]:
        return self.candles[-1].timestamp if self.candles else None
    
    def get_closes(self) -> List[float]:
        return [c.close for c in self.candles]
    
    def get_highs(self) -> List[float]:
        return [c.high for c in self.candles]
    
    def get_lows(self) -> List[float]:
        return [c.low for c in self.candles]
    
    def to_csv(self, filepath: str) -> None:
        """Export to CSV file."""
        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "open", "high", "low", "close", "volume"])
            for candle in self.candles:
                writer.writerow([
                    candle.timestamp.isoformat(),
                    candle.open,
                    candle.high,
                    candle.low,
                    candle.close,
                    candle.volume
                ])


def load_ohlcv_from_csv(
    filepath: str,
    symbol: str = "BTC/USD",
    timeframe: str = "15m"
) -> OHLCVData:
    """
    Load OHLCV data from CSV file.
    
    Expected columns: timestamp, open, high, low, close, volume
    """
    candles = []
    
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                timestamp = datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00"))
            except ValueError:
                # Try parsing as Unix timestamp
                timestamp = datetime.fromtimestamp(float(row["timestamp"]))
            
            candles.append(OHLCVCandle(
                timestamp=timestamp,
                open=float(row["open"]),
                high=float(row["high"]),
                low=float(row["low"]),
                close=float(row["close"]),
                volume=float(row.get("volume", 0))
            ))
    
    # Sort by timestamp
    candles.sort(key=lambda c: c.timestamp)
    
    logger.info(f"Loaded {len(candles)} candles from {filepath}")
    
    return OHLCVData(symbol=symbol, timeframe=timeframe, candles=candles)


def fetch_historical_data(
    exchange_id: str = "binance",  # Use Binance for historical data (free)
    symbol: str = "BTC/USDT",
    timeframe: str = "15m",
    since: Optional[datetime] = None,
    limit: int = 1000
) -> OHLCVData:
    """
    Fetch historical OHLCV data from exchange.
    
    Args:
        exchange_id: Exchange to fetch from
        symbol: Trading pair
        timeframe: Candle timeframe
        since: Start datetime
        limit: Maximum candles to fetch
    
    Returns:
        OHLCVData with historical candles
    """
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({
        "enableRateLimit": True
    })
    
    since_ms = int(since.timestamp() * 1000) if since else None
    
    logger.info(f"Fetching {symbol} {timeframe} data from {exchange_id}...")
    
    all_candles = []
    current_since = since_ms
    
    while len(all_candles) < limit:
        try:
            data = exchange.fetch_ohlcv(
                symbol,
                timeframe,
                since=current_since,
                limit=min(1000, limit - len(all_candles))
            )
            
            if not data:
                break
            
            for row in data:
                all_candles.append(OHLCVCandle.from_ccxt(row))
            
            # Move to next batch
            current_since = data[-1][0] + 1
            
            if len(data) < 1000:
                break  # No more data
                
        except Exception as e:
            logger.error(f"Error fetching data: {e}")
            break
    
    # Remove duplicates and sort
    seen = set()
    unique_candles = []
    for c in all_candles:
        key = c.timestamp.isoformat()
        if key not in seen:
            seen.add(key)
            unique_candles.append(c)
    
    unique_candles.sort(key=lambda c: c.timestamp)
    
    logger.info(f"Fetched {len(unique_candles)} candles")
    
    return OHLCVData(symbol=symbol, timeframe=timeframe, candles=unique_candles)


def generate_sample_data(
    num_candles: int = 1000,
    start_price: float = 40000.0,
    volatility: float = 0.02
) -> OHLCVData:
    """Generate sample OHLCV data for testing."""
    import random
    from datetime import timedelta
    
    candles = []
    current_price = start_price
    current_time = datetime(2024, 1, 1, 0, 0)
    
    for _ in range(num_candles):
        # Random walk
        change = current_price * volatility * random.gauss(0, 1)
        
        open_price = current_price
        close_price = current_price + change
        high_price = max(open_price, close_price) * (1 + abs(random.gauss(0, 0.005)))
        low_price = min(open_price, close_price) * (1 - abs(random.gauss(0, 0.005)))
        volume = random.uniform(100, 1000)
        
        candles.append(OHLCVCandle(
            timestamp=current_time,
            open=open_price,
            high=high_price,
            low=low_price,
            close=close_price,
            volume=volume
        ))
        
        current_price = close_price
        current_time += timedelta(minutes=15)
    
    return OHLCVData(symbol="BTC/USD", timeframe="15m", candles=candles)

"""
Backtest performance metrics calculation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from ..models.trade import Trade


@dataclass
class BacktestMetrics:
    """Complete backtest performance metrics."""
    # Basic stats
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    
    # P&L
    total_pnl: float = 0.0
    total_pnl_pct: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    largest_win: float = 0.0
    largest_loss: float = 0.0
    profit_factor: float = 0.0
    
    # Risk metrics
    max_drawdown: float = 0.0
    max_drawdown_pct: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    
    # Returns
    total_return_pct: float = 0.0
    annualized_return_pct: float = 0.0
    cagr: float = 0.0
    
    # Time stats
    avg_trade_duration: timedelta = field(default_factory=lambda: timedelta(0))
    avg_bars_in_trade: float = 0.0
    
    # Equity curve
    initial_equity: float = 0.0
    final_equity: float = 0.0
    peak_equity: float = 0.0
    equity_curve: List[float] = field(default_factory=list)
    
    # Additional
    expectancy: float = 0.0
    trades_per_day: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "total_trades": self.total_trades,
            "winning_trades": self.winning_trades,
            "losing_trades": self.losing_trades,
            "win_rate": round(self.win_rate, 2),
            "total_pnl": round(self.total_pnl, 2),
            "total_pnl_pct": round(self.total_pnl_pct, 2),
            "avg_win": round(self.avg_win, 2),
            "avg_loss": round(self.avg_loss, 2),
            "largest_win": round(self.largest_win, 2),
            "largest_loss": round(self.largest_loss, 2),
            "profit_factor": round(self.profit_factor, 2),
            "max_drawdown": round(self.max_drawdown, 2),
            "max_drawdown_pct": round(self.max_drawdown_pct, 2),
            "sharpe_ratio": round(self.sharpe_ratio, 2),
            "sortino_ratio": round(self.sortino_ratio, 2),
            "calmar_ratio": round(self.calmar_ratio, 2),
            "total_return_pct": round(self.total_return_pct, 2),
            "annualized_return_pct": round(self.annualized_return_pct, 2),
            "cagr": round(self.cagr, 2),
            "initial_equity": round(self.initial_equity, 2),
            "final_equity": round(self.final_equity, 2),
            "expectancy": round(self.expectancy, 2),
            "trades_per_day": round(self.trades_per_day, 2)
        }
    
    def summary(self) -> str:
        """Generate human-readable summary."""
        return f"""
=== Backtest Results ===
Total Trades: {self.total_trades}
Win Rate: {self.win_rate:.1f}%
Total P&L: ${self.total_pnl:,.2f} ({self.total_pnl_pct:.2f}%)

Winning Trades: {self.winning_trades} (avg: ${self.avg_win:,.2f})
Losing Trades: {self.losing_trades} (avg: ${self.avg_loss:,.2f})
Largest Win: ${self.largest_win:,.2f}
Largest Loss: ${self.largest_loss:,.2f}
Profit Factor: {self.profit_factor:.2f}

Max Drawdown: ${self.max_drawdown:,.2f} ({self.max_drawdown_pct:.2f}%)
Sharpe Ratio: {self.sharpe_ratio:.2f}
CAGR: {self.cagr:.2f}%

Initial Equity: ${self.initial_equity:,.2f}
Final Equity: ${self.final_equity:,.2f}
Expectancy: ${self.expectancy:,.2f}
"""


def calculate_metrics(
    trades: List[Trade],
    initial_equity: float,
    trading_days: int = 252,  # Crypto trades 365, but use 252 for risk-free comparison
    risk_free_rate: float = 0.04  # 4% annual risk-free rate
) -> BacktestMetrics:
    """
    Calculate comprehensive backtest metrics from trade list.
    
    Args:
        trades: List of completed trades
        initial_equity: Starting account balance
        trading_days: Trading days per year for annualization
        risk_free_rate: Annual risk-free rate for Sharpe calculation
    
    Returns:
        BacktestMetrics with all calculated values
    """
    metrics = BacktestMetrics()
    metrics.initial_equity = initial_equity
    
    if not trades:
        metrics.final_equity = initial_equity
        return metrics
    
    # Filter to closed trades only
    closed_trades = [t for t in trades if t.exit_price is not None]
    
    if not closed_trades:
        metrics.final_equity = initial_equity
        return metrics
    
    # Basic counts
    metrics.total_trades = len(closed_trades)
    winning = [t for t in closed_trades if t.realized_pnl > 0]
    losing = [t for t in closed_trades if t.realized_pnl < 0]
    
    metrics.winning_trades = len(winning)
    metrics.losing_trades = len(losing)
    metrics.win_rate = (len(winning) / len(closed_trades) * 100) if closed_trades else 0
    
    # P&L calculations
    metrics.total_pnl = sum(t.realized_pnl for t in closed_trades)
    metrics.final_equity = initial_equity + metrics.total_pnl
    metrics.total_pnl_pct = (metrics.total_pnl / initial_equity * 100) if initial_equity else 0
    
    if winning:
        metrics.avg_win = sum(t.realized_pnl for t in winning) / len(winning)
        metrics.largest_win = max(t.realized_pnl for t in winning)
    
    if losing:
        metrics.avg_loss = sum(t.realized_pnl for t in losing) / len(losing)
        metrics.largest_loss = min(t.realized_pnl for t in losing)
    
    # Profit factor
    gross_profit = sum(t.realized_pnl for t in winning) if winning else 0
    gross_loss = abs(sum(t.realized_pnl for t in losing)) if losing else 0
    metrics.profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else float('inf')
    
    # Build equity curve
    equity_curve = [initial_equity]
    running_equity = initial_equity
    
    for trade in sorted(closed_trades, key=lambda t: t.exit_time or t.created_at):
        running_equity += trade.realized_pnl
        equity_curve.append(running_equity)
    
    metrics.equity_curve = equity_curve
    metrics.peak_equity = max(equity_curve)
    
    # Drawdown calculation
    peak = equity_curve[0]
    max_dd = 0
    max_dd_pct = 0
    
    for equity in equity_curve:
        if equity > peak:
            peak = equity
        dd = peak - equity
        dd_pct = (dd / peak * 100) if peak > 0 else 0
        if dd > max_dd:
            max_dd = dd
            max_dd_pct = dd_pct
    
    metrics.max_drawdown = max_dd
    metrics.max_drawdown_pct = max_dd_pct
    
    # Calculate returns for risk metrics
    if len(equity_curve) > 1:
        returns = []
        for i in range(1, len(equity_curve)):
            if equity_curve[i-1] > 0:
                ret = (equity_curve[i] - equity_curve[i-1]) / equity_curve[i-1]
                returns.append(ret)
        
        if returns:
            # Sharpe ratio (simplified - per trade, not daily)
            avg_return = sum(returns) / len(returns)
            std_return = math.sqrt(sum((r - avg_return) ** 2 for r in returns) / len(returns)) if len(returns) > 1 else 0
            
            # Annualize (assuming avg trade duration)
            daily_rf = risk_free_rate / trading_days
            excess_return = avg_return - daily_rf
            
            if std_return > 0:
                metrics.sharpe_ratio = (excess_return / std_return) * math.sqrt(trading_days)
            
            # Sortino ratio (only downside deviation)
            downside_returns = [r for r in returns if r < 0]
            if downside_returns:
                downside_std = math.sqrt(sum(r ** 2 for r in downside_returns) / len(downside_returns))
                if downside_std > 0:
                    metrics.sortino_ratio = (excess_return / downside_std) * math.sqrt(trading_days)
    
    # Time-based metrics
    if closed_trades:
        first_trade = min(t.entry_time for t in closed_trades if t.entry_time)
        last_trade = max(t.exit_time for t in closed_trades if t.exit_time)
        
        if first_trade and last_trade:
            total_days = (last_trade - first_trade).days or 1
            metrics.trades_per_day = len(closed_trades) / total_days
            
            # CAGR
            years = total_days / 365.0
            if years > 0 and initial_equity > 0:
                metrics.cagr = ((metrics.final_equity / initial_equity) ** (1 / years) - 1) * 100
                metrics.annualized_return_pct = metrics.cagr
            
            # Calmar ratio
            if metrics.max_drawdown_pct > 0:
                metrics.calmar_ratio = metrics.cagr / metrics.max_drawdown_pct
    
    # Expectancy
    if metrics.total_trades > 0:
        win_rate_dec = metrics.win_rate / 100
        avg_win = metrics.avg_win if metrics.avg_win else 0
        avg_loss = abs(metrics.avg_loss) if metrics.avg_loss else 0
        metrics.expectancy = (win_rate_dec * avg_win) - ((1 - win_rate_dec) * avg_loss)
    
    # Return (simple)
    metrics.total_return_pct = metrics.total_pnl_pct
    
    return metrics


def export_metrics_csv(metrics: BacktestMetrics, trades: List[Trade], filepath: str) -> None:
    """Export metrics and trades to CSV."""
    import csv
    
    # Write metrics
    metrics_path = filepath.replace(".csv", "_metrics.csv")
    with open(metrics_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Metric", "Value"])
        for key, value in metrics.to_dict().items():
            writer.writerow([key, value])
    
    # Write trades
    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "id", "direction", "entry_time", "entry_price", "exit_time", 
            "exit_price", "exit_reason", "pnl", "pnl_pct"
        ])
        for trade in trades:
            writer.writerow([
                trade.id,
                trade.direction.value,
                trade.entry_time.isoformat() if trade.entry_time else "",
                trade.entry_price,
                trade.exit_time.isoformat() if trade.exit_time else "",
                trade.exit_price,
                trade.exit_reason.value if trade.exit_reason else "",
                trade.realized_pnl,
                trade.realized_pnl_pct
            ])

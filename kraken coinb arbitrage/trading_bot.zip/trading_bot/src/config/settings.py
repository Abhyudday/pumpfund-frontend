"""
Configuration settings for the trading bot.
Uses pydantic-settings for validation and environment variable loading.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import time
from enum import Enum
from functools import lru_cache
from typing import Dict, List, Optional

from dotenv import load_dotenv

load_dotenv()


class ExecutionMode(str, Enum):
    """Trading execution mode."""
    INDEPENDENT = "independent"
    ARB_HEDGE = "arb_hedge"


@dataclass
class ExchangeConfig:
    """Configuration for a single exchange."""
    name: str
    api_key: str
    api_secret: str
    passphrase: Optional[str] = None
    sandbox: bool = False
    symbols: List[str] = field(default_factory=list)


@dataclass
class SymbolMapping:
    """Symbol mapping across exchanges."""
    base: str = "BTC"
    quote_coinbase: str = "USD"
    quote_kraken: str = "USD"
    
    @property
    def coinbase_symbol(self) -> str:
        return f"{self.base}/{self.quote_coinbase}"
    
    @property
    def kraken_symbol(self) -> str:
        return f"{self.base}/{self.quote_kraken}"


@dataclass
class RiskConfig:
    """Risk management configuration."""
    stop_loss_pct: float = 6.0
    take_profit_pct: float = 15.0
    risk_pct_below_threshold: float = 2.0  # 2% when equity < 100k
    risk_pct_above_threshold: float = 1.0  # 1% when equity >= 100k (locked forever)
    equity_threshold: float = 100_000.0
    max_slippage_pct: float = 0.35


@dataclass
class TradingWindowConfig:
    """Trading window configuration."""
    blocked_start_hour: int = 22
    blocked_start_minute: int = 0
    blocked_end_hour: int = 0
    blocked_end_minute: int = 0
    max_trades_per_day: int = 2


@dataclass
class StrengthIndicatorConfig:
    """Strength indicator configuration."""
    indicator_type: str = "ADX"
    period: int = 14
    baseline: float = 20.0
    max_extension_pct: float = 1.5


@dataclass
class Settings:
    """Main settings container."""
    # Execution mode
    mode: ExecutionMode = ExecutionMode.INDEPENDENT
    paper_trading: bool = True
    
    # Exchange configurations
    coinbase: ExchangeConfig = field(default_factory=lambda: ExchangeConfig(
        name="coinbase",
        api_key=os.getenv("COINBASE_API_KEY", ""),
        api_secret=os.getenv("COINBASE_API_SECRET", ""),
        passphrase=os.getenv("COINBASE_PASSPHRASE", ""),
        sandbox=os.getenv("COINBASE_SANDBOX", "false").lower() == "true"
    ))
    kraken: ExchangeConfig = field(default_factory=lambda: ExchangeConfig(
        name="kraken",
        api_key=os.getenv("KRAKEN_API_KEY", ""),
        api_secret=os.getenv("KRAKEN_API_SECRET", ""),
        sandbox=os.getenv("KRAKEN_SANDBOX", "false").lower() == "true"
    ))
    
    # Symbol mapping
    symbols: SymbolMapping = field(default_factory=SymbolMapping)
    
    # Risk configuration
    risk: RiskConfig = field(default_factory=RiskConfig)
    
    # Trading window
    trading_window: TradingWindowConfig = field(default_factory=TradingWindowConfig)
    
    # Strength indicator
    strength: StrengthIndicatorConfig = field(default_factory=StrengthIndicatorConfig)
    
    # Webhook security
    webhook_secret: str = field(default_factory=lambda: os.getenv("WEBHOOK_SECRET", ""))
    
    # Server configuration
    host: str = "0.0.0.0"
    port: int = 8000
    
    # Database
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///trading_bot.db"))
    
    # Logging
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    log_file: str = "trading_bot.log"
    
    # Alert notifications
    alert_webhook_url: Optional[str] = field(default_factory=lambda: os.getenv("ALERT_WEBHOOK_URL"))
    alert_email: Optional[str] = field(default_factory=lambda: os.getenv("ALERT_EMAIL"))
    
    # Price tolerance for signal validation
    price_tolerance_pct: float = 0.5
    
    # Rate limiting
    rate_limit_requests_per_minute: int = 60
    rate_limit_backoff_base: float = 1.5
    rate_limit_max_retries: int = 5
    
    # Risk lock tracking (persisted separately)
    _risk_locked_to_1pct: bool = False
    
    @classmethod
    def from_env(cls) -> "Settings":
        """Load settings from environment variables."""
        mode_str = os.getenv("MODE", "independent").lower()
        mode = ExecutionMode.ARB_HEDGE if mode_str == "arb_hedge" else ExecutionMode.INDEPENDENT
        
        paper = os.getenv("PAPER", "true").lower() == "true"
        
        # Parse trading window
        blocked_start = os.getenv("BLOCKED_WINDOW_START_UTC", "22:00")
        blocked_end = os.getenv("BLOCKED_WINDOW_END_UTC", "00:00")
        
        start_parts = blocked_start.split(":")
        end_parts = blocked_end.split(":")
        
        trading_window = TradingWindowConfig(
            blocked_start_hour=int(start_parts[0]),
            blocked_start_minute=int(start_parts[1]) if len(start_parts) > 1 else 0,
            blocked_end_hour=int(end_parts[0]),
            blocked_end_minute=int(end_parts[1]) if len(end_parts) > 1 else 0,
            max_trades_per_day=int(os.getenv("MAX_TRADES_PER_DAY", "2"))
        )
        
        risk = RiskConfig(
            stop_loss_pct=float(os.getenv("STOP_LOSS_PCT", "6")),
            take_profit_pct=float(os.getenv("TAKE_PROFIT_PCT", "15")),
            risk_pct_below_threshold=float(os.getenv("RISK_PCT_THRESHOLD_1", "0.02")) * 100,
            risk_pct_above_threshold=float(os.getenv("RISK_PCT_THRESHOLD_2", "0.01")) * 100,
            max_slippage_pct=float(os.getenv("MAX_SLIPPAGE_PCT", "0.35"))
        )
        
        strength = StrengthIndicatorConfig(
            indicator_type=os.getenv("STRENGTH_INDICATOR", "ADX"),
            period=int(os.getenv("STRENGTH_PERIOD", "14")),
            baseline=float(os.getenv("STRENGTH_BASELINE", "20")),
            max_extension_pct=float(os.getenv("MAX_EXTENSION_PCT", "1.5"))
        )
        
        symbols = SymbolMapping(
            base=os.getenv("SYMBOL_BASE", "BTC"),
            quote_coinbase=os.getenv("SYMBOL_QUOTE_COINBASE", "USD"),
            quote_kraken=os.getenv("SYMBOL_QUOTE_KRAKEN", "USD")
        )
        
        return cls(
            mode=mode,
            paper_trading=paper,
            symbols=symbols,
            risk=risk,
            trading_window=trading_window,
            strength=strength
        )
    
    def is_in_blocked_window(self, current_time: time) -> bool:
        """Check if current time is within the blocked trading window."""
        blocked_start = time(self.trading_window.blocked_start_hour, 
                            self.trading_window.blocked_start_minute)
        blocked_end = time(self.trading_window.blocked_end_hour,
                          self.trading_window.blocked_end_minute)
        
        # Handle overnight window (e.g., 22:00 to 00:00)
        if blocked_start > blocked_end:
            return current_time >= blocked_start or current_time < blocked_end
        else:
            return blocked_start <= current_time < blocked_end
    
    def get_risk_percentage(self, equity: float, risk_locked: bool = False) -> float:
        """
        Get the risk percentage based on account equity.
        Once equity reaches 100k, 1% risk is locked forever.
        """
        if risk_locked or self._risk_locked_to_1pct or equity >= self.risk.equity_threshold:
            self._risk_locked_to_1pct = True
            return self.risk.risk_pct_above_threshold / 100
        return self.risk.risk_pct_below_threshold / 100


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings.from_env()

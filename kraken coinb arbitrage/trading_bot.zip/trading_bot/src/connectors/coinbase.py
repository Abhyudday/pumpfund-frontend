"""
Coinbase Pro exchange connector using CCXT.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Dict, Optional

import ccxt.async_support as ccxt_async

from ..config import Settings
from ..models.order import OCOOrder, Order, OrderSide, OrderStatus, OrderType
from .base import BaseExchangeConnector

logger = logging.getLogger(__name__)


class CoinbaseConnector(BaseExchangeConnector):
    """
    Coinbase Pro (Advanced Trade) connector.
    
    Note: Coinbase Pro has been migrated to Coinbase Advanced Trade.
    CCXT supports this via the 'coinbase' exchange class.
    """
    
    def __init__(self, settings: Settings):
        super().__init__(settings, "coinbase", settings.coinbase.sandbox)
        self._quote_currency = settings.symbols.quote_coinbase
    
    @property
    def symbol(self) -> str:
        """Get the trading symbol for Coinbase."""
        return f"{self.settings.symbols.base}/{self._quote_currency}"
    
    async def initialize(self) -> None:
        """Initialize the Coinbase connection."""
        self._exchange = ccxt_async.coinbase({
            "apiKey": self.settings.coinbase.api_key,
            "secret": self.settings.coinbase.api_secret,
            "password": self.settings.coinbase.passphrase,  # Required for Coinbase Pro
            "sandbox": self.sandbox,
            "enableRateLimit": True,
            "options": {
                "adjustForTimeDifference": True,
                "recvWindow": 60000
            }
        })
        
        if self.sandbox:
            self._exchange.set_sandbox_mode(True)
        
        # Load markets
        await self._execute_with_retry(
            self._exchange.load_markets,
            operation_name="load_markets"
        )
        
        self.logger.info(f"Coinbase connector initialized, symbol: {self.symbol}")
    
    async def close(self) -> None:
        """Close the Coinbase connection."""
        if self._exchange:
            await self._exchange.close()
            self._exchange = None
    
    def supports_margin(self) -> bool:
        """Coinbase Advanced Trade does not support margin trading for most users."""
        return False
    
    def supports_oco(self) -> bool:
        """Coinbase does not support native OCO orders."""
        return False
    
    async def place_oco_order(
        self,
        entry_price: float,
        position_size: float,
        stop_loss_price: float,
        take_profit_price: float,
        side: OrderSide
    ) -> OCOOrder:
        """
        Place OCO order on Coinbase.
        Since Coinbase doesn't support native OCO, we place both orders
        and implement cancel-on-fill logic via monitoring.
        """
        exit_side = OrderSide.SELL if side == OrderSide.BUY else OrderSide.BUY
        
        oco = OCOOrder(
            exchange=self.exchange_name,
            symbol=self.symbol,
            entry_price=entry_price,
            position_size=position_size,
            side=side
        )
        
        # Create stop loss order
        oco.create_stop_loss(stop_loss_price)
        oco.create_take_profit(take_profit_price)
        
        # Place stop loss order
        try:
            sl_order = await self.create_stop_loss_order(
                side=exit_side,
                amount=position_size,
                stop_price=stop_loss_price
            )
            oco.stop_loss_order = sl_order
            
            if sl_order.status == OrderStatus.FAILED:
                oco.status = "failed"
                return oco
            
        except Exception as e:
            self.logger.error(f"Failed to place stop loss: {e}")
            oco.status = "failed"
            return oco
        
        # Place take profit as limit order
        try:
            tp_order = await self.create_limit_order(
                side=exit_side,
                amount=position_size,
                price=take_profit_price,
                params={"postOnly": False}  # Ensure fill
            )
            oco.take_profit_order = tp_order
            
            if tp_order.status == OrderStatus.FAILED:
                # Rollback: cancel the stop loss
                if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                    await self.cancel_order(oco.stop_loss_order.exchange_order_id)
                oco.status = "failed"
                return oco
            
        except Exception as e:
            self.logger.error(f"Failed to place take profit: {e}")
            # Rollback stop loss
            if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                await self.cancel_order(oco.stop_loss_order.exchange_order_id)
            oco.status = "failed"
            return oco
        
        oco.status = "active"
        self.logger.info(
            f"OCO placed: SL={stop_loss_price}, TP={take_profit_price}, "
            f"size={position_size}"
        )
        
        return oco
    
    async def monitor_oco(self, oco: OCOOrder) -> OCOOrder:
        """
        Monitor OCO orders and cancel the other when one fills.
        This should be called periodically for active OCO orders.
        """
        if oco.status != "active":
            return oco
        
        # Check stop loss status
        if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
            sl_status = await self.fetch_order(oco.stop_loss_order.exchange_order_id)
            oco.stop_loss_order = sl_status
            
            if sl_status.is_filled:
                # Stop loss triggered, cancel take profit
                if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
                    await self.cancel_order(oco.take_profit_order.exchange_order_id)
                oco.status = "triggered"
                oco.triggered_order = "stop_loss"
                self.logger.info(f"OCO {oco.id}: Stop loss triggered")
                return oco
        
        # Check take profit status
        if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
            tp_status = await self.fetch_order(oco.take_profit_order.exchange_order_id)
            oco.take_profit_order = tp_status
            
            if tp_status.is_filled:
                # Take profit triggered, cancel stop loss
                if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                    await self.cancel_order(oco.stop_loss_order.exchange_order_id)
                oco.status = "triggered"
                oco.triggered_order = "take_profit"
                self.logger.info(f"OCO {oco.id}: Take profit triggered")
                return oco
        
        return oco
    
    async def cancel_oco(self, oco: OCOOrder) -> bool:
        """Cancel both orders in an OCO."""
        success = True
        
        if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
            if not await self.cancel_order(oco.stop_loss_order.exchange_order_id):
                success = False
        
        if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
            if not await self.cancel_order(oco.take_profit_order.exchange_order_id):
                success = False
        
        if success:
            oco.status = "cancelled"
        
        return success

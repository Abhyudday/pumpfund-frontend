"""
Kraken exchange connector using CCXT.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Dict, Optional

import ccxt.async_support as ccxt_async

from ..config import Settings
from ..models.order import OCOOrder, Order, OrderSide, OrderStatus, OrderType
from .base import BaseExchangeConnector

logger = logging.getLogger(__name__)


class KrakenConnector(BaseExchangeConnector):
    """
    Kraken exchange connector.
    
    Kraken supports margin trading and has some OCO-like functionality
    via conditional orders.
    """
    
    def __init__(self, settings: Settings):
        super().__init__(settings, "kraken", settings.kraken.sandbox)
        self._quote_currency = settings.symbols.quote_kraken
    
    @property
    def symbol(self) -> str:
        """Get the trading symbol for Kraken."""
        return f"{self.settings.symbols.base}/{self._quote_currency}"
    
    async def initialize(self) -> None:
        """Initialize the Kraken connection."""
        self._exchange = ccxt_async.kraken({
            "apiKey": self.settings.kraken.api_key,
            "secret": self.settings.kraken.api_secret,
            "enableRateLimit": True,
            "options": {
                "adjustForTimeDifference": True
            }
        })
        
        if self.sandbox:
            # Kraken doesn't have a true sandbox, but we can use demo mode
            self.logger.warning("Kraken sandbox mode not fully supported")
        
        # Load markets
        await self._execute_with_retry(
            self._exchange.load_markets,
            operation_name="load_markets"
        )
        
        self.logger.info(f"Kraken connector initialized, symbol: {self.symbol}")
    
    async def close(self) -> None:
        """Close the Kraken connection."""
        if self._exchange:
            await self._exchange.close()
            self._exchange = None
    
    def supports_margin(self) -> bool:
        """Kraken supports margin trading for eligible accounts."""
        return True
    
    def supports_oco(self) -> bool:
        """Kraken has conditional orders but not true OCO."""
        return False
    
    async def create_margin_order(
        self,
        side: OrderSide,
        amount: float,
        leverage: int = 2,
        params: Optional[Dict] = None
    ) -> Order:
        """
        Create a margin order for short selling.
        
        Args:
            side: Order side (buy/sell)
            amount: Order amount
            leverage: Leverage ratio (default 2x)
            params: Additional parameters
        """
        self.logger.info(
            f"Creating margin {side.value} order: {amount} {self.symbol} @ {leverage}x"
        )
        
        margin_params = {
            "leverage": leverage,
            **(params or {})
        }
        
        try:
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "market",
                side.value,
                amount,
                None,
                margin_params,
                operation_name="create_margin_order"
            )
            
            return self._parse_order_response(data, OrderType.MARKET, side, amount)
        
        except Exception as e:
            self.logger.error(f"Failed to create margin order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.MARKET,
                side=side,
                amount=amount,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def create_stop_loss_order(
        self,
        side: OrderSide,
        amount: float,
        stop_price: float,
        params: Optional[Dict] = None
    ) -> Order:
        """Create a stop loss order on Kraken."""
        self.logger.info(
            f"Creating stop loss {side.value} order: {amount} {self.symbol} @ stop {stop_price}"
        )
        
        try:
            # Kraken uses 'stop-loss' order type
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "stop-loss",
                side.value,
                amount,
                stop_price,  # Kraken uses price for stop-loss
                params or {},
                operation_name="create_stop_loss_order"
            )
            
            order = self._parse_order_response(data, OrderType.STOP_LOSS, side, amount)
            order.stop_price = stop_price
            return order
        
        except Exception as e:
            self.logger.error(f"Failed to create stop loss order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.STOP_LOSS,
                side=side,
                amount=amount,
                stop_price=stop_price,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def create_take_profit_order(
        self,
        side: OrderSide,
        amount: float,
        price: float,
        params: Optional[Dict] = None
    ) -> Order:
        """Create a take profit order on Kraken."""
        self.logger.info(
            f"Creating take profit {side.value} order: {amount} {self.symbol} @ {price}"
        )
        
        try:
            # Kraken uses 'take-profit' order type
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "take-profit",
                side.value,
                amount,
                price,
                params or {},
                operation_name="create_take_profit_order"
            )
            
            order = self._parse_order_response(data, OrderType.TAKE_PROFIT, side, amount, price)
            return order
        
        except Exception as e:
            self.logger.error(f"Failed to create take profit order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.TAKE_PROFIT,
                side=side,
                amount=amount,
                price=price,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def place_oco_order(
        self,
        entry_price: float,
        position_size: float,
        stop_loss_price: float,
        take_profit_price: float,
        side: OrderSide
    ) -> OCOOrder:
        """
        Place OCO order on Kraken.
        Kraken doesn't have native OCO, so we place both orders
        and monitor for fills.
        """
        exit_side = OrderSide.SELL if side == OrderSide.BUY else OrderSide.BUY
        
        oco = OCOOrder(
            exchange=self.exchange_name,
            symbol=self.symbol,
            entry_price=entry_price,
            position_size=position_size,
            side=side
        )
        
        # Create stop loss order
        oco.create_stop_loss(stop_loss_price)
        oco.create_take_profit(take_profit_price)
        
        # Place stop loss
        try:
            sl_order = await self.create_stop_loss_order(
                side=exit_side,
                amount=position_size,
                stop_price=stop_loss_price
            )
            oco.stop_loss_order = sl_order
            
            if sl_order.status == OrderStatus.FAILED:
                oco.status = "failed"
                return oco
            
        except Exception as e:
            self.logger.error(f"Failed to place stop loss: {e}")
            oco.status = "failed"
            return oco
        
        # Place take profit
        try:
            tp_order = await self.create_take_profit_order(
                side=exit_side,
                amount=position_size,
                price=take_profit_price
            )
            oco.take_profit_order = tp_order
            
            if tp_order.status == OrderStatus.FAILED:
                # Rollback stop loss
                if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                    await self.cancel_order(oco.stop_loss_order.exchange_order_id)
                oco.status = "failed"
                return oco
            
        except Exception as e:
            self.logger.error(f"Failed to place take profit: {e}")
            if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                await self.cancel_order(oco.stop_loss_order.exchange_order_id)
            oco.status = "failed"
            return oco
        
        oco.status = "active"
        self.logger.info(
            f"OCO placed on Kraken: SL={stop_loss_price}, TP={take_profit_price}, "
            f"size={position_size}"
        )
        
        return oco
    
    async def monitor_oco(self, oco: OCOOrder) -> OCOOrder:
        """Monitor OCO orders and cancel the other when one fills."""
        if oco.status != "active":
            return oco
        
        # Check stop loss status
        if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
            sl_status = await self.fetch_order(oco.stop_loss_order.exchange_order_id)
            oco.stop_loss_order = sl_status
            
            if sl_status.is_filled:
                if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
                    await self.cancel_order(oco.take_profit_order.exchange_order_id)
                oco.status = "triggered"
                oco.triggered_order = "stop_loss"
                self.logger.info(f"OCO {oco.id}: Stop loss triggered")
                return oco
        
        # Check take profit status
        if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
            tp_status = await self.fetch_order(oco.take_profit_order.exchange_order_id)
            oco.take_profit_order = tp_status
            
            if tp_status.is_filled:
                if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
                    await self.cancel_order(oco.stop_loss_order.exchange_order_id)
                oco.status = "triggered"
                oco.triggered_order = "take_profit"
                self.logger.info(f"OCO {oco.id}: Take profit triggered")
                return oco
        
        return oco
    
    async def cancel_oco(self, oco: OCOOrder) -> bool:
        """Cancel both orders in an OCO."""
        success = True
        
        if oco.stop_loss_order and oco.stop_loss_order.exchange_order_id:
            if not await self.cancel_order(oco.stop_loss_order.exchange_order_id):
                success = False
        
        if oco.take_profit_order and oco.take_profit_order.exchange_order_id:
            if not await self.cancel_order(oco.take_profit_order.exchange_order_id):
                success = False
        
        if success:
            oco.status = "cancelled"
        
        return success
    
    async def get_margin_balance(self) -> float:
        """Get available margin balance."""
        try:
            balance = await self._execute_with_retry(
                self._exchange.fetch_balance,
                operation_name="fetch_balance"
            )
            
            # Kraken includes margin info in balance
            margin_info = balance.get("info", {}).get("result", {})
            return float(margin_info.get("mf", 0))  # Free margin
        
        except Exception as e:
            self.logger.error(f"Failed to get margin balance: {e}")
            return 0.0

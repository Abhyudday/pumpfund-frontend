"""
Base exchange connector interface.
"""
from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import ccxt
import ccxt.async_support as ccxt_async

from ..config import Settings
from ..models.order import OCOOrder, Order, OrderSide, OrderStatus, OrderType

logger = logging.getLogger(__name__)


@dataclass
class TickerData:
    """Market ticker data."""
    symbol: str
    bid: float
    ask: float
    last: float
    volume: float
    timestamp: datetime


@dataclass
class BalanceInfo:
    """Account balance information."""
    total: float
    free: float
    used: float
    currency: str


@dataclass
class OrderBookEntry:
    """Single order book entry."""
    price: float
    amount: float


@dataclass
class OrderBook:
    """Order book snapshot."""
    symbol: str
    bids: List[OrderBookEntry]
    asks: List[OrderBookEntry]
    timestamp: datetime
    
    @property
    def best_bid(self) -> float:
        return self.bids[0].price if self.bids else 0
    
    @property
    def best_ask(self) -> float:
        return self.asks[0].price if self.asks else 0
    
    @property
    def mid_price(self) -> float:
        return (self.best_bid + self.best_ask) / 2 if self.best_bid and self.best_ask else 0
    
    @property
    def spread(self) -> float:
        return self.best_ask - self.best_bid if self.best_bid and self.best_ask else 0
    
    @property
    def spread_pct(self) -> float:
        return (self.spread / self.mid_price * 100) if self.mid_price else 0


class RateLimiter:
    """Simple rate limiter with exponential backoff."""
    
    def __init__(
        self,
        requests_per_minute: int = 60,
        backoff_base: float = 1.5,
        max_retries: int = 5
    ):
        self.requests_per_minute = requests_per_minute
        self.backoff_base = backoff_base
        self.max_retries = max_retries
        self.min_interval = 60.0 / requests_per_minute
        self.last_request_time = 0.0
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> None:
        """Wait until rate limit allows next request."""
        async with self._lock:
            now = time.time()
            elapsed = now - self.last_request_time
            if elapsed < self.min_interval:
                await asyncio.sleep(self.min_interval - elapsed)
            self.last_request_time = time.time()
    
    def get_backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay."""
        return self.backoff_base ** attempt


class BaseExchangeConnector(ABC):
    """
    Abstract base class for exchange connectors.
    Implements common functionality and defines interface.
    """
    
    def __init__(
        self,
        settings: Settings,
        exchange_name: str,
        sandbox: bool = False
    ):
        self.settings = settings
        self.exchange_name = exchange_name
        self.sandbox = sandbox
        self._exchange: Optional[ccxt_async.Exchange] = None
        self._sync_exchange: Optional[ccxt.Exchange] = None
        self.rate_limiter = RateLimiter(
            requests_per_minute=settings.rate_limit_requests_per_minute,
            backoff_base=settings.rate_limit_backoff_base,
            max_retries=settings.rate_limit_max_retries
        )
        self.logger = logging.getLogger(f"{__name__}.{exchange_name}")
    
    @property
    @abstractmethod
    def symbol(self) -> str:
        """Get the trading symbol for this exchange."""
        pass
    
    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the exchange connection."""
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """Close the exchange connection."""
        pass
    
    @abstractmethod
    def supports_margin(self) -> bool:
        """Check if exchange supports margin/short trading."""
        pass
    
    @abstractmethod
    def supports_oco(self) -> bool:
        """Check if exchange supports native OCO orders."""
        pass
    
    async def _execute_with_retry(
        self,
        func,
        *args,
        operation_name: str = "operation",
        **kwargs
    ) -> Any:
        """
        Execute exchange operation with rate limiting and retry logic.
        """
        last_error = None
        
        for attempt in range(self.rate_limiter.max_retries):
            try:
                await self.rate_limiter.acquire()
                return await func(*args, **kwargs)
            
            except ccxt.RateLimitExceeded as e:
                delay = self.rate_limiter.get_backoff_delay(attempt)
                self.logger.warning(
                    f"Rate limit exceeded on {operation_name}, "
                    f"backing off {delay:.2f}s (attempt {attempt + 1})"
                )
                await asyncio.sleep(delay)
                last_error = e
            
            except ccxt.NetworkError as e:
                delay = self.rate_limiter.get_backoff_delay(attempt)
                self.logger.warning(
                    f"Network error on {operation_name}: {e}, "
                    f"retrying in {delay:.2f}s (attempt {attempt + 1})"
                )
                await asyncio.sleep(delay)
                last_error = e
            
            except ccxt.ExchangeError as e:
                self.logger.error(f"Exchange error on {operation_name}: {e}")
                raise
        
        raise last_error or Exception(f"Max retries exceeded for {operation_name}")
    
    async def fetch_ticker(self) -> TickerData:
        """Fetch current ticker data."""
        data = await self._execute_with_retry(
            self._exchange.fetch_ticker,
            self.symbol,
            operation_name="fetch_ticker"
        )
        
        return TickerData(
            symbol=self.symbol,
            bid=float(data.get("bid", 0)),
            ask=float(data.get("ask", 0)),
            last=float(data.get("last", 0)),
            volume=float(data.get("baseVolume", 0)),
            timestamp=datetime.fromtimestamp(data.get("timestamp", 0) / 1000)
        )
    
    async def fetch_order_book(self, limit: int = 10) -> OrderBook:
        """Fetch order book snapshot."""
        data = await self._execute_with_retry(
            self._exchange.fetch_order_book,
            self.symbol,
            limit,
            operation_name="fetch_order_book"
        )
        
        return OrderBook(
            symbol=self.symbol,
            bids=[OrderBookEntry(price=b[0], amount=b[1]) for b in data.get("bids", [])],
            asks=[OrderBookEntry(price=a[0], amount=a[1]) for a in data.get("asks", [])],
            timestamp=datetime.fromtimestamp(data.get("timestamp", 0) / 1000) if data.get("timestamp") else datetime.utcnow()
        )
    
    async def fetch_balance(self, currency: str = "USD") -> BalanceInfo:
        """Fetch account balance for a currency."""
        data = await self._execute_with_retry(
            self._exchange.fetch_balance,
            operation_name="fetch_balance"
        )
        
        balance = data.get(currency, {})
        return BalanceInfo(
            total=float(balance.get("total", 0)),
            free=float(balance.get("free", 0)),
            used=float(balance.get("used", 0)),
            currency=currency
        )
    
    async def fetch_total_equity(self, quote_currency: str = "USD") -> float:
        """
        Fetch total account equity in quote currency.
        Includes all balances converted to quote currency.
        """
        data = await self._execute_with_retry(
            self._exchange.fetch_balance,
            operation_name="fetch_balance"
        )
        
        total = data.get("total", {})
        equity = float(total.get(quote_currency, 0))
        
        # Add value of other holdings
        btc_balance = float(total.get("BTC", 0))
        if btc_balance > 0:
            ticker = await self.fetch_ticker()
            equity += btc_balance * ticker.last
        
        return equity
    
    async def create_market_order(
        self,
        side: OrderSide,
        amount: float,
        params: Optional[Dict] = None
    ) -> Order:
        """Create a market order."""
        self.logger.info(f"Creating market {side.value} order: {amount} {self.symbol}")
        
        try:
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "market",
                side.value,
                amount,
                None,  # price not needed for market order
                params or {},
                operation_name="create_market_order"
            )
            
            return self._parse_order_response(data, OrderType.MARKET, side, amount)
        
        except Exception as e:
            self.logger.error(f"Failed to create market order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.MARKET,
                side=side,
                amount=amount,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def create_limit_order(
        self,
        side: OrderSide,
        amount: float,
        price: float,
        params: Optional[Dict] = None
    ) -> Order:
        """Create a limit order."""
        self.logger.info(
            f"Creating limit {side.value} order: {amount} {self.symbol} @ {price}"
        )
        
        try:
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "limit",
                side.value,
                amount,
                price,
                params or {},
                operation_name="create_limit_order"
            )
            
            return self._parse_order_response(data, OrderType.LIMIT, side, amount, price)
        
        except Exception as e:
            self.logger.error(f"Failed to create limit order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.LIMIT,
                side=side,
                amount=amount,
                price=price,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def create_stop_loss_order(
        self,
        side: OrderSide,
        amount: float,
        stop_price: float,
        params: Optional[Dict] = None
    ) -> Order:
        """Create a stop loss order."""
        self.logger.info(
            f"Creating stop loss {side.value} order: {amount} {self.symbol} @ stop {stop_price}"
        )
        
        try:
            data = await self._execute_with_retry(
                self._exchange.create_order,
                self.symbol,
                "stop",
                side.value,
                amount,
                None,
                {"stopPrice": stop_price, **(params or {})},
                operation_name="create_stop_loss_order"
            )
            
            order = self._parse_order_response(data, OrderType.STOP_LOSS, side, amount)
            order.stop_price = stop_price
            return order
        
        except Exception as e:
            self.logger.error(f"Failed to create stop loss order: {e}")
            return Order(
                exchange=self.exchange_name,
                symbol=self.symbol,
                order_type=OrderType.STOP_LOSS,
                side=side,
                amount=amount,
                stop_price=stop_price,
                status=OrderStatus.FAILED,
                error_message=str(e)
            )
    
    async def fetch_order(self, order_id: str) -> Order:
        """Fetch order status by ID."""
        data = await self._execute_with_retry(
            self._exchange.fetch_order,
            order_id,
            self.symbol,
            operation_name="fetch_order"
        )
        
        return self._parse_order_response(
            data,
            OrderType(data.get("type", "market")),
            OrderSide(data.get("side", "buy")),
            float(data.get("amount", 0)),
            float(data.get("price")) if data.get("price") else None
        )
    
    async def cancel_order(self, order_id: str) -> bool:
        """Cancel an order by ID."""
        try:
            await self._execute_with_retry(
                self._exchange.cancel_order,
                order_id,
                self.symbol,
                operation_name="cancel_order"
            )
            self.logger.info(f"Cancelled order {order_id}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to cancel order {order_id}: {e}")
            return False
    
    async def fetch_open_orders(self) -> List[Order]:
        """Fetch all open orders."""
        data = await self._execute_with_retry(
            self._exchange.fetch_open_orders,
            self.symbol,
            operation_name="fetch_open_orders"
        )
        
        return [
            self._parse_order_response(
                o,
                OrderType(o.get("type", "market")),
                OrderSide(o.get("side", "buy")),
                float(o.get("amount", 0)),
                float(o.get("price")) if o.get("price") else None
            )
            for o in data
        ]
    
    async def fetch_ohlcv(
        self,
        timeframe: str = "15m",
        since: Optional[int] = None,
        limit: int = 100
    ) -> List[List]:
        """Fetch OHLCV candle data."""
        return await self._execute_with_retry(
            self._exchange.fetch_ohlcv,
            self.symbol,
            timeframe,
            since,
            limit,
            operation_name="fetch_ohlcv"
        )
    
    def _parse_order_response(
        self,
        data: Dict[str, Any],
        order_type: OrderType,
        side: OrderSide,
        amount: float,
        price: Optional[float] = None
    ) -> Order:
        """Parse CCXT order response to Order model."""
        status_map = {
            "open": OrderStatus.OPEN,
            "closed": OrderStatus.FILLED,
            "canceled": OrderStatus.CANCELLED,
            "cancelled": OrderStatus.CANCELLED,
            "expired": OrderStatus.EXPIRED,
            "rejected": OrderStatus.REJECTED
        }
        
        raw_status = data.get("status", "open")
        status = status_map.get(raw_status, OrderStatus.OPEN)
        
        filled_amount = float(data.get("filled", 0))
        if filled_amount > 0 and filled_amount < amount:
            status = OrderStatus.PARTIALLY_FILLED
        
        return Order(
            exchange=self.exchange_name,
            symbol=self.symbol,
            order_type=order_type,
            side=side,
            amount=amount,
            price=price,
            status=status,
            exchange_order_id=data.get("id"),
            filled_amount=filled_amount,
            filled_price=float(data.get("average")) if data.get("average") else None,
            fee=float(data.get("fee", {}).get("cost", 0)) if data.get("fee") else 0,
            fee_currency=data.get("fee", {}).get("currency", "USD") if data.get("fee") else "USD",
            raw_response=data
        )
    
    @abstractmethod
    async def place_oco_order(
        self,
        entry_price: float,
        position_size: float,
        stop_loss_price: float,
        take_profit_price: float,
        side: OrderSide
    ) -> OCOOrder:
        """
        Place OCO (One-Cancels-Other) order for SL and TP.
        Implementation varies by exchange.
        """
        pass

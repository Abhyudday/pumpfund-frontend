"""
Exchange manager for coordinating multiple exchange connections.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from ..config import ExecutionMode, Settings
from ..models.order import OCOOrder, Order, OrderSide, OrderStatus
from ..models.trade import Trade, TradeDirection
from .base import BaseExchangeConnector, OrderBook, TickerData
from .coinbase import CoinbaseConnector
from .kraken import KrakenConnector

logger = logging.getLogger(__name__)


@dataclass
class ExchangePrices:
    """Price comparison across exchanges."""
    coinbase: Optional[TickerData] = None
    kraken: Optional[TickerData] = None
    
    @property
    def cheaper_for_buy(self) -> Optional[str]:
        """Determine which exchange is cheaper for buying."""
        if not self.coinbase or not self.kraken:
            return None
        if self.coinbase.ask < self.kraken.ask:
            return "coinbase"
        return "kraken"
    
    @property
    def cheaper_for_sell(self) -> Optional[str]:
        """Determine which exchange offers better sell price."""
        if not self.coinbase or not self.kraken:
            return None
        if self.coinbase.bid > self.kraken.bid:
            return "coinbase"
        return "kraken"
    
    @property
    def spread_opportunity(self) -> float:
        """Calculate arbitrage spread opportunity."""
        if not self.coinbase or not self.kraken:
            return 0.0
        
        # Buy on cheaper, sell on more expensive
        buy_price = min(self.coinbase.ask, self.kraken.ask)
        sell_price = max(self.coinbase.bid, self.kraken.bid)
        
        if buy_price <= 0:
            return 0.0
        
        return (sell_price - buy_price) / buy_price * 100


class ExchangeManager:
    """
    Manages connections to multiple exchanges and coordinates trading operations.
    
    Supports two modes:
    1. Independent execution: Same trade on both exchanges
    2. Arb-aware mode: Buy on cheaper, hedge on more expensive
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.coinbase: Optional[CoinbaseConnector] = None
        self.kraken: Optional[KrakenConnector] = None
        self._initialized = False
        self.logger = logging.getLogger(__name__)
    
    async def initialize(self) -> None:
        """Initialize all exchange connections."""
        self.logger.info("Initializing exchange connections...")
        
        # Initialize Coinbase
        self.coinbase = CoinbaseConnector(self.settings)
        await self.coinbase.initialize()
        
        # Initialize Kraken
        self.kraken = KrakenConnector(self.settings)
        await self.kraken.initialize()
        
        self._initialized = True
        self.logger.info("All exchange connections initialized")
    
    async def close(self) -> None:
        """Close all exchange connections."""
        if self.coinbase:
            await self.coinbase.close()
        if self.kraken:
            await self.kraken.close()
        self._initialized = False
    
    def get_connector(self, exchange: str) -> BaseExchangeConnector:
        """Get connector for specified exchange."""
        if exchange == "coinbase":
            return self.coinbase
        elif exchange == "kraken":
            return self.kraken
        else:
            raise ValueError(f"Unknown exchange: {exchange}")
    
    async def fetch_prices(self) -> ExchangePrices:
        """Fetch current prices from all exchanges."""
        prices = ExchangePrices()
        
        try:
            coinbase_task = self.coinbase.fetch_ticker()
            kraken_task = self.kraken.fetch_ticker()
            
            results = await asyncio.gather(
                coinbase_task, kraken_task,
                return_exceptions=True
            )
            
            if not isinstance(results[0], Exception):
                prices.coinbase = results[0]
            else:
                self.logger.error(f"Coinbase price fetch failed: {results[0]}")
            
            if not isinstance(results[1], Exception):
                prices.kraken = results[1]
            else:
                self.logger.error(f"Kraken price fetch failed: {results[1]}")
        
        except Exception as e:
            self.logger.error(f"Price fetch failed: {e}")
        
        return prices
    
    async def fetch_total_equity(self) -> Tuple[float, Dict[str, float]]:
        """
        Fetch total equity across all exchanges.
        
        Returns:
            Tuple of (total_equity, {exchange: equity})
        """
        equities = {}
        
        try:
            results = await asyncio.gather(
                self.coinbase.fetch_total_equity(),
                self.kraken.fetch_total_equity(),
                return_exceptions=True
            )
            
            if not isinstance(results[0], Exception):
                equities["coinbase"] = results[0]
            else:
                self.logger.error(f"Coinbase equity fetch failed: {results[0]}")
                equities["coinbase"] = 0.0
            
            if not isinstance(results[1], Exception):
                equities["kraken"] = results[1]
            else:
                self.logger.error(f"Kraken equity fetch failed: {results[1]}")
                equities["kraken"] = 0.0
        
        except Exception as e:
            self.logger.error(f"Equity fetch failed: {e}")
            return 0.0, {}
        
        total = sum(equities.values())
        return total, equities
    
    async def execute_independent_trade(
        self,
        direction: TradeDirection,
        position_size: float,
        entry_price: float,
        stop_loss_price: float,
        take_profit_price: float,
        paper_mode: bool = False
    ) -> Dict[str, Trade]:
        """
        Execute the same directional trade on both exchanges.
        
        Args:
            direction: Long or short
            position_size: Size per exchange
            entry_price: Expected entry price
            stop_loss_price: Stop loss level
            take_profit_price: Take profit level
            paper_mode: If True, simulate only
        
        Returns:
            Dict mapping exchange name to Trade object
        """
        trades = {}
        side = OrderSide.BUY if direction == TradeDirection.LONG else OrderSide.SELL
        
        for exchange_name, connector in [("coinbase", self.coinbase), ("kraken", self.kraken)]:
            trade = Trade(
                exchange=exchange_name,
                symbol=connector.symbol,
                direction=direction,
                paper_trade=paper_mode
            )
            
            if paper_mode:
                # Simulate entry
                trade.entry_price = entry_price
                trade.entry_amount = position_size
                trade.entry_value = entry_price * position_size
                trade.entry_time = datetime.utcnow()
                trade.set_exit_levels(
                    self.settings.risk.stop_loss_pct,
                    self.settings.risk.take_profit_pct
                )
                trade.status = "open"
                trades[exchange_name] = trade
                self.logger.info(f"[PAPER] {exchange_name}: {direction.value} {position_size} @ {entry_price}")
                continue
            
            # Check if short is supported
            if direction == TradeDirection.SHORT and not connector.supports_margin():
                self.logger.warning(f"{exchange_name} does not support shorts, skipping")
                trade.status = "failed"
                trade.notes = "Exchange does not support margin/shorts"
                trades[exchange_name] = trade
                continue
            
            # Execute entry order
            try:
                if direction == TradeDirection.SHORT and exchange_name == "kraken":
                    order = await connector.create_margin_order(side, position_size)
                else:
                    order = await connector.create_market_order(side, position_size)
                
                if order.status == OrderStatus.FAILED:
                    trade.status = "failed"
                    trade.notes = order.error_message
                    trades[exchange_name] = trade
                    continue
                
                # Wait for fill
                await asyncio.sleep(1)
                order = await connector.fetch_order(order.exchange_order_id)
                
                trade.entry_order_id = order.exchange_order_id
                trade.entry_price = order.filled_price or entry_price
                trade.entry_amount = order.filled_amount
                trade.entry_value = trade.entry_price * trade.entry_amount
                trade.entry_fee = order.fee
                trade.entry_time = datetime.utcnow()
                trade.set_exit_levels(
                    self.settings.risk.stop_loss_pct,
                    self.settings.risk.take_profit_pct
                )
                
                # Place OCO orders
                oco = await connector.place_oco_order(
                    entry_price=trade.entry_price,
                    position_size=trade.entry_amount,
                    stop_loss_price=trade.stop_loss_price,
                    take_profit_price=trade.take_profit_price,
                    side=side
                )
                
                trade.oco_order_id = oco.id
                trade.status = "open" if oco.status == "active" else "failed"
                trades[exchange_name] = trade
                
                self.logger.info(
                    f"{exchange_name}: {direction.value} {trade.entry_amount} @ {trade.entry_price}, "
                    f"SL={trade.stop_loss_price}, TP={trade.take_profit_price}"
                )
            
            except Exception as e:
                self.logger.error(f"Trade execution failed on {exchange_name}: {e}")
                trade.status = "failed"
                trade.notes = str(e)
                trades[exchange_name] = trade
        
        return trades
    
    async def execute_arb_hedge_trade(
        self,
        direction: TradeDirection,
        position_size: float,
        entry_price: float,
        stop_loss_price: float,
        take_profit_price: float,
        paper_mode: bool = False
    ) -> Dict[str, Trade]:
        """
        Execute arbitrage-aware trade: buy on cheaper, hedge on more expensive.
        
        If full hedging not possible, falls back to independent execution.
        """
        prices = await self.fetch_prices()
        
        # Determine best execution
        if direction == TradeDirection.LONG:
            buy_exchange = prices.cheaper_for_buy
            hedge_exchange = "kraken" if buy_exchange == "coinbase" else "coinbase"
        else:
            buy_exchange = prices.cheaper_for_sell
            hedge_exchange = "kraken" if buy_exchange == "coinbase" else "coinbase"
        
        if not buy_exchange:
            self.logger.warning("Cannot determine best exchange, falling back to independent")
            return await self.execute_independent_trade(
                direction, position_size, entry_price,
                stop_loss_price, take_profit_price, paper_mode
            )
        
        # Check if hedge exchange supports shorts
        hedge_connector = self.get_connector(hedge_exchange)
        if not hedge_connector.supports_margin():
            self.logger.warning(
                f"{hedge_exchange} does not support hedging (no margin), "
                "falling back to independent execution"
            )
            return await self.execute_independent_trade(
                direction, position_size, entry_price,
                stop_loss_price, take_profit_price, paper_mode
            )
        
        spread = prices.spread_opportunity
        self.logger.info(
            f"Arb-hedge mode: Buy on {buy_exchange}, hedge on {hedge_exchange}, "
            f"spread opportunity: {spread:.3f}%"
        )
        
        trades = {}
        
        # Execute primary trade
        buy_connector = self.get_connector(buy_exchange)
        buy_side = OrderSide.BUY if direction == TradeDirection.LONG else OrderSide.SELL
        
        buy_trade = Trade(
            exchange=buy_exchange,
            symbol=buy_connector.symbol,
            direction=direction,
            paper_trade=paper_mode
        )
        
        if paper_mode:
            buy_trade.entry_price = entry_price
            buy_trade.entry_amount = position_size
            buy_trade.entry_value = entry_price * position_size
            buy_trade.entry_time = datetime.utcnow()
            buy_trade.set_exit_levels(
                self.settings.risk.stop_loss_pct,
                self.settings.risk.take_profit_pct
            )
            buy_trade.status = "open"
            trades[buy_exchange] = buy_trade
        else:
            try:
                order = await buy_connector.create_market_order(buy_side, position_size)
                await asyncio.sleep(1)
                order = await buy_connector.fetch_order(order.exchange_order_id)
                
                buy_trade.entry_order_id = order.exchange_order_id
                buy_trade.entry_price = order.filled_price or entry_price
                buy_trade.entry_amount = order.filled_amount
                buy_trade.entry_value = buy_trade.entry_price * buy_trade.entry_amount
                buy_trade.entry_fee = order.fee
                buy_trade.entry_time = datetime.utcnow()
                buy_trade.set_exit_levels(
                    self.settings.risk.stop_loss_pct,
                    self.settings.risk.take_profit_pct
                )
                
                oco = await buy_connector.place_oco_order(
                    entry_price=buy_trade.entry_price,
                    position_size=buy_trade.entry_amount,
                    stop_loss_price=buy_trade.stop_loss_price,
                    take_profit_price=buy_trade.take_profit_price,
                    side=buy_side
                )
                
                buy_trade.oco_order_id = oco.id
                buy_trade.status = "open" if oco.status == "active" else "failed"
                trades[buy_exchange] = buy_trade
                
            except Exception as e:
                self.logger.error(f"Primary trade failed: {e}")
                buy_trade.status = "failed"
                buy_trade.notes = str(e)
                trades[buy_exchange] = buy_trade
                return trades
        
        # Execute hedge trade (opposite direction)
        hedge_direction = TradeDirection.SHORT if direction == TradeDirection.LONG else TradeDirection.LONG
        hedge_side = OrderSide.SELL if direction == TradeDirection.LONG else OrderSide.BUY
        
        hedge_trade = Trade(
            exchange=hedge_exchange,
            symbol=hedge_connector.symbol,
            direction=hedge_direction,
            paper_trade=paper_mode,
            notes="Hedge position for arb"
        )
        
        if paper_mode:
            hedge_trade.entry_price = entry_price
            hedge_trade.entry_amount = position_size
            hedge_trade.entry_value = entry_price * position_size
            hedge_trade.entry_time = datetime.utcnow()
            hedge_trade.set_exit_levels(
                self.settings.risk.stop_loss_pct,
                self.settings.risk.take_profit_pct
            )
            hedge_trade.status = "open"
            trades[hedge_exchange] = hedge_trade
        else:
            try:
                if hedge_exchange == "kraken":
                    order = await self.kraken.create_margin_order(hedge_side, position_size)
                else:
                    order = await hedge_connector.create_market_order(hedge_side, position_size)
                
                await asyncio.sleep(1)
                order = await hedge_connector.fetch_order(order.exchange_order_id)
                
                hedge_trade.entry_order_id = order.exchange_order_id
                hedge_trade.entry_price = order.filled_price or entry_price
                hedge_trade.entry_amount = order.filled_amount
                hedge_trade.entry_value = hedge_trade.entry_price * hedge_trade.entry_amount
                hedge_trade.entry_fee = order.fee
                hedge_trade.entry_time = datetime.utcnow()
                hedge_trade.set_exit_levels(
                    self.settings.risk.stop_loss_pct,
                    self.settings.risk.take_profit_pct
                )
                
                oco = await hedge_connector.place_oco_order(
                    entry_price=hedge_trade.entry_price,
                    position_size=hedge_trade.entry_amount,
                    stop_loss_price=hedge_trade.stop_loss_price,
                    take_profit_price=hedge_trade.take_profit_price,
                    side=hedge_side
                )
                
                hedge_trade.oco_order_id = oco.id
                hedge_trade.status = "open" if oco.status == "active" else "failed"
                trades[hedge_exchange] = hedge_trade
                
            except Exception as e:
                self.logger.error(f"Hedge trade failed: {e}")
                hedge_trade.status = "failed"
                hedge_trade.notes = str(e)
                trades[hedge_exchange] = hedge_trade
        
        return trades
    
    async def execute_trade(
        self,
        direction: TradeDirection,
        position_size: float,
        entry_price: float,
        stop_loss_price: float,
        take_profit_price: float
    ) -> Dict[str, Trade]:
        """
        Execute trade according to configured mode.
        """
        paper_mode = self.settings.paper_trading
        
        if self.settings.mode == ExecutionMode.ARB_HEDGE:
            return await self.execute_arb_hedge_trade(
                direction, position_size, entry_price,
                stop_loss_price, take_profit_price, paper_mode
            )
        else:
            return await self.execute_independent_trade(
                direction, position_size, entry_price,
                stop_loss_price, take_profit_price, paper_mode
            )
    
    async def monitor_active_ocos(self, oco_ids: Dict[str, str]) -> Dict[str, OCOOrder]:
        """
        Monitor active OCO orders across exchanges.
        
        Args:
            oco_ids: Dict mapping exchange name to OCO order ID
        
        Returns:
            Updated OCO orders
        """
        results = {}
        
        for exchange_name, oco_id in oco_ids.items():
            connector = self.get_connector(exchange_name)
            # This would need to track OCOs in the database
            # For now, just return empty
            pass
        
        return results

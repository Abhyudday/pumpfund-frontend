"""
Trade execution service coordinating signals, risk, and exchanges.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from ..config import Settings
from ..connectors.manager import ExchangeManager
from ..models.order import OCOOrder
from ..models.signal import Signal, SignalType
from ..models.trade import Trade, TradeDirection, TradeStatus
from ..utils.risk import RiskCalculator, PositionSizeResult
from ..utils.validation import SignalValidator
from .database import Database
from .notifications import NotificationService

logger = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    """Result of trade execution."""
    success: bool
    trades: Dict[str, Trade]
    signal: Signal
    position_size: Optional[PositionSizeResult] = None
    error_message: Optional[str] = None
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


class TradeExecutor:
    """
    Coordinates the full trade execution flow:
    1. Validate signal
    2. Calculate position size
    3. Execute on exchanges
    4. Place OCO orders
    5. Persist state
    """
    
    def __init__(
        self,
        settings: Settings,
        exchange_manager: ExchangeManager,
        database: Database,
        notifications: Optional[NotificationService] = None
    ):
        self.settings = settings
        self.exchange_manager = exchange_manager
        self.database = database
        self.notifications = notifications
        self.validator = SignalValidator(settings)
        self.risk_calculator = RiskCalculator(settings)
        
        # Load risk lock state from database
        if database.is_risk_locked():
            self.risk_calculator.set_risk_locked(True)
    
    async def process_signal(self, signal: Signal) -> ExecutionResult:
        """
        Process a validated signal and execute trades.
        
        Args:
            signal: Validated trading signal
        
        Returns:
            ExecutionResult with trade details
        """
        logger.info(f"Processing signal: {signal.signal_type.value} @ ${signal.close_price:,.2f}")
        
        # Check if signal already processed (deduplication)
        if self.database.is_signal_processed(signal.unique_id):
            return ExecutionResult(
                success=False,
                trades={},
                signal=signal,
                error_message=f"Duplicate signal rejected: {signal.unique_id}"
            )
        
        # Check daily trade limit
        trade_count = self.database.get_daily_trade_count()
        max_trades = self.settings.trading_window.max_trades_per_day
        
        if trade_count >= max_trades:
            return ExecutionResult(
                success=False,
                trades={},
                signal=signal,
                error_message=f"Daily trade limit reached: {trade_count}/{max_trades}"
            )
        
        # Fetch current prices and equity
        try:
            prices = await self.exchange_manager.fetch_prices()
            total_equity, equity_breakdown = await self.exchange_manager.fetch_total_equity()
        except Exception as e:
            logger.error(f"Failed to fetch market data: {e}")
            return ExecutionResult(
                success=False,
                trades={},
                signal=signal,
                error_message=f"Failed to fetch market data: {e}"
            )
        
        # Validate price tolerance
        warnings = []
        if prices.coinbase:
            is_valid, deviation = self.validator.validate_price_tolerance(
                signal.close_price, prices.coinbase.last
            )
            if not is_valid:
                warnings.append(f"Coinbase price deviation: {deviation:.2f}%")
        
        if prices.kraken:
            is_valid, deviation = self.validator.validate_price_tolerance(
                signal.close_price, prices.kraken.last
            )
            if not is_valid:
                warnings.append(f"Kraken price deviation: {deviation:.2f}%")
        
        # Calculate position size
        entry_price = signal.close_price
        if prices.coinbase and prices.kraken:
            # Use mid price for calculation
            entry_price = (prices.coinbase.last + prices.kraken.last) / 2
        
        direction = TradeDirection.LONG if signal.is_buy else TradeDirection.SHORT
        
        position_result = self.risk_calculator.calculate_position_size(
            equity=total_equity,
            entry_price=entry_price,
            is_long=signal.is_buy
        )
        
        if not position_result.is_valid:
            return ExecutionResult(
                success=False,
                trades={},
                signal=signal,
                position_size=position_result,
                error_message=position_result.rejection_reason
            )
        
        # Update risk lock state if needed
        if self.risk_calculator.is_risk_locked():
            self.database.set_risk_locked(True)
        
        # Validate balances
        # For independent mode, need balance on both exchanges
        # For arb mode, need balance on at least the buy exchange
        for exchange_name, equity in equity_breakdown.items():
            is_valid, error = self.risk_calculator.validate_balance(
                required_value=position_result.position_value,
                available_balance=equity
            )
            if not is_valid:
                logger.warning(f"{exchange_name}: {error}")
                if not self.settings.paper_trading:
                    warnings.append(f"{exchange_name}: {error}")
        
        # Execute trades
        try:
            trades = await self.exchange_manager.execute_trade(
                direction=direction,
                position_size=position_result.position_size,
                entry_price=entry_price,
                stop_loss_price=position_result.stop_loss_price,
                take_profit_price=position_result.take_profit_price
            )
        except Exception as e:
            logger.error(f"Trade execution failed: {e}")
            if self.notifications:
                await self.notifications.send_alert(
                    f"Trade execution failed: {e}",
                    level="error"
                )
            return ExecutionResult(
                success=False,
                trades={},
                signal=signal,
                position_size=position_result,
                error_message=str(e)
            )
        
        # Persist trades and update counters
        success_count = 0
        for exchange_name, trade in trades.items():
            trade.signal_id = signal.unique_id
            self.database.save_trade(trade)
            
            if trade.status == "open":
                success_count += 1
                logger.info(f"Trade opened on {exchange_name}: {trade.id}")
        
        # Mark signal as processed
        self.database.mark_signal_processed(signal.unique_id, signal.raw_payload)
        
        # Increment daily trade count (count as one logical trade)
        if success_count > 0:
            self.database.increment_daily_trade_count(list(trades.values())[0].id)
        
        # Send notification
        if self.notifications and success_count > 0:
            await self.notifications.send_trade_notification(trades)
        
        return ExecutionResult(
            success=success_count > 0,
            trades=trades,
            signal=signal,
            position_size=position_result,
            warnings=warnings
        )
    
    async def monitor_open_trades(self) -> List[Trade]:
        """
        Monitor all open trades and check OCO status.
        Called periodically by background worker.
        
        Returns:
            List of trades that were closed
        """
        closed_trades = []
        open_trades = self.database.get_open_trades()
        
        for trade in open_trades:
            if not trade.oco_order_id:
                continue
            
            try:
                connector = self.exchange_manager.get_connector(trade.exchange)
                
                # This would need the full OCO object - simplified here
                # In practice, we'd store and retrieve the full OCO
                oco_orders = self.database.get_active_oco_orders()
                
                for oco in oco_orders:
                    if oco.id == trade.oco_order_id:
                        if hasattr(connector, 'monitor_oco'):
                            updated_oco = await connector.monitor_oco(oco)
                            
                            if updated_oco.is_triggered:
                                # Close the trade
                                if updated_oco.triggered_order == "stop_loss":
                                    exit_price = trade.stop_loss_price
                                    from ..models.trade import ExitReason
                                    exit_reason = ExitReason.STOP_LOSS
                                else:
                                    exit_price = trade.take_profit_price
                                    exit_reason = ExitReason.TAKE_PROFIT
                                
                                trade.close(
                                    exit_price=exit_price,
                                    exit_amount=trade.entry_amount,
                                    exit_reason=exit_reason
                                )
                                
                                self.database.save_trade(trade)
                                self.database.save_oco_order(updated_oco)
                                closed_trades.append(trade)
                                
                                logger.info(
                                    f"Trade {trade.id} closed via {exit_reason.value}: "
                                    f"PnL ${trade.realized_pnl:,.2f} ({trade.realized_pnl_pct:.2f}%)"
                                )
                                
                                if self.notifications:
                                    await self.notifications.send_trade_closed(trade)
            
            except Exception as e:
                logger.error(f"Error monitoring trade {trade.id}: {e}")
        
        return closed_trades
    
    async def cancel_all_open_orders(self, exchange: Optional[str] = None) -> int:
        """
        Cancel all open orders on specified exchange(s).
        
        Args:
            exchange: Optional exchange name. If None, cancels on all.
        
        Returns:
            Number of orders cancelled
        """
        cancelled = 0
        
        exchanges = [exchange] if exchange else ["coinbase", "kraken"]
        
        for exch in exchanges:
            try:
                connector = self.exchange_manager.get_connector(exch)
                open_orders = await connector.fetch_open_orders()
                
                for order in open_orders:
                    if order.exchange_order_id:
                        if await connector.cancel_order(order.exchange_order_id):
                            cancelled += 1
            except Exception as e:
                logger.error(f"Error cancelling orders on {exch}: {e}")
        
        return cancelled
    
    def get_bot_status(self) -> Dict:
        """Get current bot status for admin API."""
        open_trades = self.database.get_open_trades()
        today_count = self.database.get_daily_trade_count()
        stats = self.database.get_trade_statistics()
        
        return {
            "mode": self.settings.mode.value,
            "paper_trading": self.settings.paper_trading,
            "open_trades": len(open_trades),
            "trades_today": today_count,
            "max_trades_per_day": self.settings.trading_window.max_trades_per_day,
            "risk_locked_to_1pct": self.risk_calculator.is_risk_locked(),
            "statistics": stats
        }

"""
Notification service for alerts and trade updates.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

import httpx

from ..config import Settings
from ..models.trade import Trade

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Handles notifications via webhook and email.
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.webhook_url = settings.alert_webhook_url
        self.email = settings.alert_email
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client
    
    async def close(self) -> None:
        """Close HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def send_webhook(self, payload: Dict[str, Any]) -> bool:
        """Send notification via webhook."""
        if not self.webhook_url:
            return False
        
        try:
            client = await self._get_client()
            response = await client.post(
                self.webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()
            return True
        except Exception as e:
            logger.error(f"Webhook notification failed: {e}")
            return False
    
    async def send_alert(
        self,
        message: str,
        level: str = "info",
        data: Optional[Dict] = None
    ) -> bool:
        """
        Send alert notification.
        
        Args:
            message: Alert message
            level: Alert level (info, warning, error, critical)
            data: Optional additional data
        """
        payload = {
            "type": "alert",
            "level": level,
            "message": message,
            "data": data or {},
            "bot": "trading_bot",
            "paper_mode": self.settings.paper_trading
        }
        
        logger.log(
            logging.ERROR if level in ["error", "critical"] else logging.INFO,
            f"Alert [{level}]: {message}"
        )
        
        return await self.send_webhook(payload)
    
    async def send_trade_notification(self, trades: Dict[str, Trade]) -> bool:
        """Send notification about new trades."""
        trade_data = []
        
        for exchange, trade in trades.items():
            trade_data.append({
                "exchange": exchange,
                "direction": trade.direction.value,
                "entry_price": trade.entry_price,
                "amount": trade.entry_amount,
                "stop_loss": trade.stop_loss_price,
                "take_profit": trade.take_profit_price,
                "status": trade.status if isinstance(trade.status, str) else trade.status.value
            })
        
        payload = {
            "type": "trade_opened",
            "trades": trade_data,
            "paper_mode": self.settings.paper_trading
        }
        
        return await self.send_webhook(payload)
    
    async def send_trade_closed(self, trade: Trade) -> bool:
        """Send notification about closed trade."""
        payload = {
            "type": "trade_closed",
            "trade": {
                "id": trade.id,
                "exchange": trade.exchange,
                "direction": trade.direction.value,
                "entry_price": trade.entry_price,
                "exit_price": trade.exit_price,
                "exit_reason": trade.exit_reason.value if trade.exit_reason else None,
                "pnl": trade.realized_pnl,
                "pnl_pct": trade.realized_pnl_pct
            },
            "paper_mode": self.settings.paper_trading
        }
        
        return await self.send_webhook(payload)
    
    async def send_error_notification(
        self,
        error: str,
        context: Optional[Dict] = None
    ) -> bool:
        """Send critical error notification."""
        return await self.send_alert(
            message=f"Critical Error: {error}",
            level="critical",
            data=context
        )
    
    async def send_daily_summary(
        self,
        stats: Dict[str, Any],
        trades: List[Trade]
    ) -> bool:
        """Send daily trading summary."""
        payload = {
            "type": "daily_summary",
            "statistics": stats,
            "trades_count": len(trades),
            "paper_mode": self.settings.paper_trading
        }
        
        return await self.send_webhook(payload)

"""
Database service for trade persistence using SQLite.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime, date
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional

from ..models.trade import DailyTradeCounter, Trade, TradeStatus
from ..models.order import OCOOrder

logger = logging.getLogger(__name__)


class Database:
    """
    SQLite database for persisting trades, orders, and state.
    """
    
    def __init__(self, db_path: str = "trading_bot.db"):
        self.db_path = db_path
        self._ensure_db_directory()
        self._init_schema()
    
    def _ensure_db_directory(self) -> None:
        """Ensure database directory exists."""
        db_dir = Path(self.db_path).parent
        if db_dir and not db_dir.exists():
            db_dir.mkdir(parents=True, exist_ok=True)
    
    @contextmanager
    def _get_connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Get database connection context manager."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def _init_schema(self) -> None:
        """Initialize database schema."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Trades table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id TEXT PRIMARY KEY,
                    signal_id TEXT,
                    exchange TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    status TEXT NOT NULL,
                    entry_price REAL,
                    entry_amount REAL,
                    entry_value REAL,
                    entry_order_id TEXT,
                    entry_time TEXT,
                    entry_fee REAL DEFAULT 0,
                    exit_price REAL,
                    exit_amount REAL,
                    exit_value REAL,
                    exit_order_id TEXT,
                    exit_time TEXT,
                    exit_fee REAL DEFAULT 0,
                    exit_reason TEXT,
                    stop_loss_price REAL,
                    take_profit_price REAL,
                    oco_order_id TEXT,
                    realized_pnl REAL DEFAULT 0,
                    realized_pnl_pct REAL DEFAULT 0,
                    notes TEXT,
                    paper_trade INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # OCO orders table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS oco_orders (
                    id TEXT PRIMARY KEY,
                    trade_id TEXT,
                    exchange TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    entry_price REAL,
                    position_size REAL,
                    side TEXT,
                    stop_loss_order_id TEXT,
                    take_profit_order_id TEXT,
                    status TEXT NOT NULL,
                    triggered_order TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    data TEXT,
                    FOREIGN KEY (trade_id) REFERENCES trades(id)
                )
            """)
            
            # Daily trade counters
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS daily_trade_counters (
                    date TEXT PRIMARY KEY,
                    count INTEGER DEFAULT 0,
                    trade_ids TEXT
                )
            """)
            
            # Processed signals for deduplication
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS processed_signals (
                    signal_id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    payload TEXT
                )
            """)
            
            # Bot state/settings
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS bot_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_exchange ON trades(exchange)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_created_at ON trades(created_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_oco_status ON oco_orders(status)")
            
            logger.info(f"Database initialized: {self.db_path}")
    
    # Trade operations
    def save_trade(self, trade: Trade) -> None:
        """Save or update a trade."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR REPLACE INTO trades (
                    id, signal_id, exchange, symbol, direction, status,
                    entry_price, entry_amount, entry_value, entry_order_id, entry_time, entry_fee,
                    exit_price, exit_amount, exit_value, exit_order_id, exit_time, exit_fee, exit_reason,
                    stop_loss_price, take_profit_price, oco_order_id,
                    realized_pnl, realized_pnl_pct, notes, paper_trade, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                trade.id, trade.signal_id, trade.exchange, trade.symbol,
                trade.direction.value, trade.status.value if isinstance(trade.status, TradeStatus) else trade.status,
                trade.entry_price, trade.entry_amount, trade.entry_value,
                trade.entry_order_id, trade.entry_time.isoformat() if trade.entry_time else None, trade.entry_fee,
                trade.exit_price, trade.exit_amount, trade.exit_value,
                trade.exit_order_id, trade.exit_time.isoformat() if trade.exit_time else None, trade.exit_fee,
                trade.exit_reason.value if trade.exit_reason else None,
                trade.stop_loss_price, trade.take_profit_price, trade.oco_order_id,
                trade.realized_pnl, trade.realized_pnl_pct, trade.notes,
                1 if trade.paper_trade else 0,
                trade.created_at.isoformat(), trade.updated_at.isoformat()
            ))
    
    def get_trade(self, trade_id: str) -> Optional[Trade]:
        """Get trade by ID."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades WHERE id = ?", (trade_id,))
            row = cursor.fetchone()
            
            if row:
                return Trade.from_dict(dict(row))
            return None
    
    def get_trades_by_status(self, status: str) -> List[Trade]:
        """Get all trades with given status."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades WHERE status = ? ORDER BY created_at DESC", (status,))
            return [Trade.from_dict(dict(row)) for row in cursor.fetchall()]
    
    def get_open_trades(self) -> List[Trade]:
        """Get all open trades."""
        return self.get_trades_by_status("open")
    
    def get_recent_trades(self, limit: int = 10) -> List[Trade]:
        """Get most recent trades."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades ORDER BY created_at DESC LIMIT ?", (limit,))
            return [Trade.from_dict(dict(row)) for row in cursor.fetchall()]
    
    def get_trades_for_date(self, trade_date: date) -> List[Trade]:
        """Get all trades for a specific date."""
        date_str = trade_date.isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM trades WHERE created_at LIKE ? ORDER BY created_at",
                (f"{date_str}%",)
            )
            return [Trade.from_dict(dict(row)) for row in cursor.fetchall()]
    
    # OCO order operations
    def save_oco_order(self, oco: OCOOrder) -> None:
        """Save or update an OCO order."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR REPLACE INTO oco_orders (
                    id, trade_id, exchange, symbol, entry_price, position_size, side,
                    stop_loss_order_id, take_profit_order_id, status, triggered_order,
                    created_at, updated_at, data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                oco.id, oco.trade_id, oco.exchange, oco.symbol,
                oco.entry_price, oco.position_size, oco.side.value,
                oco.stop_loss_order.exchange_order_id if oco.stop_loss_order else None,
                oco.take_profit_order.exchange_order_id if oco.take_profit_order else None,
                oco.status, oco.triggered_order,
                oco.created_at.isoformat(), oco.updated_at.isoformat(),
                json.dumps(oco.to_dict())
            ))
    
    def get_active_oco_orders(self) -> List[OCOOrder]:
        """Get all active OCO orders."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM oco_orders WHERE status = 'active'")
            return [OCOOrder.from_dict(json.loads(row["data"])) for row in cursor.fetchall()]
    
    # Daily trade counter operations
    def get_daily_trade_count(self, trade_date: Optional[date] = None) -> int:
        """Get trade count for a specific date (defaults to today UTC)."""
        if trade_date is None:
            trade_date = datetime.utcnow().date()
        
        date_str = trade_date.isoformat()
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT count FROM daily_trade_counters WHERE date = ?", (date_str,))
            row = cursor.fetchone()
            return row["count"] if row else 0
    
    def increment_daily_trade_count(self, trade_id: str, trade_date: Optional[date] = None) -> int:
        """Increment daily trade count and return new count."""
        if trade_date is None:
            trade_date = datetime.utcnow().date()
        
        date_str = trade_date.isoformat()
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Get current state
            cursor.execute("SELECT count, trade_ids FROM daily_trade_counters WHERE date = ?", (date_str,))
            row = cursor.fetchone()
            
            if row:
                count = row["count"] + 1
                trade_ids = json.loads(row["trade_ids"] or "[]")
                trade_ids.append(trade_id)
            else:
                count = 1
                trade_ids = [trade_id]
            
            cursor.execute("""
                INSERT OR REPLACE INTO daily_trade_counters (date, count, trade_ids)
                VALUES (?, ?, ?)
            """, (date_str, count, json.dumps(trade_ids)))
            
            return count
    
    def can_trade_today(self, max_trades: int) -> bool:
        """Check if more trades are allowed today."""
        return self.get_daily_trade_count() < max_trades
    
    # Signal deduplication
    def is_signal_processed(self, signal_id: str) -> bool:
        """Check if a signal has already been processed."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM processed_signals WHERE signal_id = ?", (signal_id,))
            return cursor.fetchone() is not None
    
    def mark_signal_processed(self, signal_id: str, payload: Optional[str] = None) -> None:
        """Mark a signal as processed."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO processed_signals (signal_id, timestamp, payload)
                VALUES (?, ?, ?)
            """, (signal_id, datetime.utcnow().isoformat(), payload))
    
    # Bot state operations
    def get_state(self, key: str, default: Any = None) -> Any:
        """Get a state value."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM bot_state WHERE key = ?", (key,))
            row = cursor.fetchone()
            
            if row:
                try:
                    return json.loads(row["value"])
                except json.JSONDecodeError:
                    return row["value"]
            return default
    
    def set_state(self, key: str, value: Any) -> None:
        """Set a state value."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            if isinstance(value, (dict, list)):
                value_str = json.dumps(value)
            else:
                value_str = str(value)
            
            cursor.execute("""
                INSERT OR REPLACE INTO bot_state (key, value, updated_at)
                VALUES (?, ?, ?)
            """, (key, value_str, datetime.utcnow().isoformat()))
    
    def is_risk_locked(self) -> bool:
        """Check if risk is locked to 1%."""
        return self.get_state("risk_locked_to_1pct", False)
    
    def set_risk_locked(self, locked: bool = True) -> None:
        """Set risk lock state."""
        self.set_state("risk_locked_to_1pct", locked)
    
    # Cleanup
    def cleanup_old_signals(self, days: int = 30) -> int:
        """Remove processed signals older than N days."""
        cutoff = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        cutoff = cutoff.replace(day=cutoff.day - days)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM processed_signals WHERE timestamp < ?",
                (cutoff.isoformat(),)
            )
            return cursor.rowcount
    
    def get_trade_statistics(self, start_date: Optional[date] = None, end_date: Optional[date] = None) -> Dict[str, Any]:
        """Get aggregate trade statistics."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            query = "SELECT * FROM trades WHERE status = 'closed'"
            params = []
            
            if start_date:
                query += " AND created_at >= ?"
                params.append(start_date.isoformat())
            if end_date:
                query += " AND created_at <= ?"
                params.append(f"{end_date.isoformat()}T23:59:59")
            
            cursor.execute(query, params)
            trades = [Trade.from_dict(dict(row)) for row in cursor.fetchall()]
            
            if not trades:
                return {
                    "total_trades": 0,
                    "winning_trades": 0,
                    "losing_trades": 0,
                    "win_rate": 0,
                    "total_pnl": 0,
                    "avg_win": 0,
                    "avg_loss": 0,
                    "largest_win": 0,
                    "largest_loss": 0
                }
            
            winning = [t for t in trades if t.realized_pnl > 0]
            losing = [t for t in trades if t.realized_pnl < 0]
            
            return {
                "total_trades": len(trades),
                "winning_trades": len(winning),
                "losing_trades": len(losing),
                "win_rate": len(winning) / len(trades) * 100 if trades else 0,
                "total_pnl": sum(t.realized_pnl for t in trades),
                "avg_win": sum(t.realized_pnl for t in winning) / len(winning) if winning else 0,
                "avg_loss": sum(t.realized_pnl for t in losing) / len(losing) if losing else 0,
                "largest_win": max((t.realized_pnl for t in winning), default=0),
                "largest_loss": min((t.realized_pnl for t in losing), default=0)
            }

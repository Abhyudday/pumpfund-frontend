"""
Paper trading simulator for testing without real orders.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
import random

from ..config import Settings
from ..models.order import OCOOrder, Order, OrderSide, OrderStatus, OrderType
from ..models.trade import Trade, TradeDirection, TradeStatus, ExitReason
from ..connectors.base import TickerData, OrderBook, BalanceInfo

logger = logging.getLogger(__name__)


@dataclass
class PaperPosition:
    """Simulated open position."""
    trade_id: str
    exchange: str
    symbol: str
    direction: TradeDirection
    entry_price: float
    amount: float
    stop_loss: float
    take_profit: float
    entry_time: datetime = field(default_factory=datetime.utcnow)


@dataclass
class PaperAccount:
    """Simulated exchange account."""
    exchange: str
    initial_balance: float
    balance: float
    positions: List[PaperPosition] = field(default_factory=list)
    realized_pnl: float = 0.0
    trade_history: List[Trade] = field(default_factory=list)


class PaperTradingSimulator:
    """
    Simulates trading execution for paper trading mode.
    Tracks positions, calculates P&L, and simulates SL/TP triggers.
    """
    
    def __init__(self, settings: Settings, initial_balance: float = 10000.0):
        self.settings = settings
        self.initial_balance = initial_balance
        self.accounts: Dict[str, PaperAccount] = {
            "coinbase": PaperAccount(
                exchange="coinbase",
                initial_balance=initial_balance,
                balance=initial_balance
            ),
            "kraken": PaperAccount(
                exchange="kraken",
                initial_balance=initial_balance,
                balance=initial_balance
            )
        }
        self.logger = logging.getLogger(__name__)
    
    def get_account(self, exchange: str) -> PaperAccount:
        """Get paper account for exchange."""
        return self.accounts.get(exchange)
    
    def get_total_equity(self) -> float:
        """Get total equity across all accounts."""
        return sum(acc.balance for acc in self.accounts.values())
    
    def get_balance(self, exchange: str) -> BalanceInfo:
        """Get balance for an exchange."""
        account = self.get_account(exchange)
        if not account:
            return BalanceInfo(total=0, free=0, used=0, currency="USD")
        
        # Calculate used balance (in positions)
        used = sum(pos.entry_price * pos.amount for pos in account.positions)
        
        return BalanceInfo(
            total=account.balance,
            free=account.balance - used,
            used=used,
            currency="USD"
        )
    
    def simulate_market_order(
        self,
        exchange: str,
        side: OrderSide,
        amount: float,
        current_price: float,
        slippage_pct: float = 0.1
    ) -> Order:
        """
        Simulate a market order execution.
        
        Applies simulated slippage.
        """
        # Simulate slippage
        slippage = current_price * (slippage_pct / 100) * random.uniform(0.5, 1.5)
        if side == OrderSide.BUY:
            fill_price = current_price + slippage
        else:
            fill_price = current_price - slippage
        
        # Simulate fee (0.1%)
        fee = fill_price * amount * 0.001
        
        order = Order(
            exchange=exchange,
            symbol=f"BTC/{self.settings.symbols.quote_coinbase}",
            order_type=OrderType.MARKET,
            side=side,
            amount=amount,
            status=OrderStatus.FILLED,
            exchange_order_id=f"paper_{datetime.utcnow().timestamp()}",
            filled_amount=amount,
            filled_price=fill_price,
            fee=fee,
            fee_currency="USD"
        )
        
        # Update account balance
        account = self.get_account(exchange)
        if account:
            if side == OrderSide.BUY:
                account.balance -= (fill_price * amount + fee)
            else:
                account.balance += (fill_price * amount - fee)
        
        self.logger.info(
            f"[PAPER] {exchange}: {side.value} {amount:.6f} @ ${fill_price:,.2f}, "
            f"fee: ${fee:.2f}"
        )
        
        return order
    
    def open_position(
        self,
        exchange: str,
        direction: TradeDirection,
        entry_price: float,
        amount: float,
        stop_loss: float,
        take_profit: float
    ) -> Trade:
        """Open a paper position."""
        account = self.get_account(exchange)
        if not account:
            raise ValueError(f"Unknown exchange: {exchange}")
        
        trade = Trade(
            exchange=exchange,
            symbol=f"BTC/{self.settings.symbols.quote_coinbase}",
            direction=direction,
            status=TradeStatus.OPEN,
            entry_price=entry_price,
            entry_amount=amount,
            entry_value=entry_price * amount,
            entry_time=datetime.utcnow(),
            stop_loss_price=stop_loss,
            take_profit_price=take_profit,
            paper_trade=True
        )
        
        position = PaperPosition(
            trade_id=trade.id,
            exchange=exchange,
            symbol=trade.symbol,
            direction=direction,
            entry_price=entry_price,
            amount=amount,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
        
        account.positions.append(position)
        
        self.logger.info(
            f"[PAPER] Position opened: {direction.value} {amount:.6f} BTC @ ${entry_price:,.2f}, "
            f"SL=${stop_loss:,.2f}, TP=${take_profit:,.2f}"
        )
        
        return trade
    
    def check_sl_tp(self, exchange: str, current_price: float) -> List[Trade]:
        """
        Check if any positions hit stop loss or take profit.
        
        Returns list of closed trades.
        """
        account = self.get_account(exchange)
        if not account:
            return []
        
        closed_trades = []
        positions_to_close = []
        
        for pos in account.positions:
            triggered = False
            exit_reason = None
            exit_price = current_price
            
            if pos.direction == TradeDirection.LONG:
                if current_price <= pos.stop_loss:
                    triggered = True
                    exit_reason = ExitReason.STOP_LOSS
                    exit_price = pos.stop_loss
                elif current_price >= pos.take_profit:
                    triggered = True
                    exit_reason = ExitReason.TAKE_PROFIT
                    exit_price = pos.take_profit
            else:  # SHORT
                if current_price >= pos.stop_loss:
                    triggered = True
                    exit_reason = ExitReason.STOP_LOSS
                    exit_price = pos.stop_loss
                elif current_price <= pos.take_profit:
                    triggered = True
                    exit_reason = ExitReason.TAKE_PROFIT
                    exit_price = pos.take_profit
            
            if triggered:
                positions_to_close.append((pos, exit_reason, exit_price))
        
        for pos, exit_reason, exit_price in positions_to_close:
            trade = self.close_position(
                exchange=exchange,
                position=pos,
                exit_price=exit_price,
                exit_reason=exit_reason
            )
            closed_trades.append(trade)
        
        return closed_trades
    
    def close_position(
        self,
        exchange: str,
        position: PaperPosition,
        exit_price: float,
        exit_reason: ExitReason
    ) -> Trade:
        """Close a paper position."""
        account = self.get_account(exchange)
        
        # Calculate P&L
        if position.direction == TradeDirection.LONG:
            pnl = (exit_price - position.entry_price) * position.amount
        else:
            pnl = (position.entry_price - exit_price) * position.amount
        
        pnl_pct = (pnl / (position.entry_price * position.amount)) * 100
        
        # Update account
        account.balance += pnl + (position.entry_price * position.amount)
        account.realized_pnl += pnl
        account.positions.remove(position)
        
        trade = Trade(
            id=position.trade_id,
            exchange=exchange,
            symbol=position.symbol,
            direction=position.direction,
            status=TradeStatus.CLOSED,
            entry_price=position.entry_price,
            entry_amount=position.amount,
            entry_value=position.entry_price * position.amount,
            entry_time=position.entry_time,
            exit_price=exit_price,
            exit_amount=position.amount,
            exit_value=exit_price * position.amount,
            exit_time=datetime.utcnow(),
            exit_reason=exit_reason,
            stop_loss_price=position.stop_loss,
            take_profit_price=position.take_profit,
            realized_pnl=pnl,
            realized_pnl_pct=pnl_pct,
            paper_trade=True
        )
        
        account.trade_history.append(trade)
        
        self.logger.info(
            f"[PAPER] Position closed: {exit_reason.value} @ ${exit_price:,.2f}, "
            f"PnL: ${pnl:,.2f} ({pnl_pct:.2f}%)"
        )
        
        return trade
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get paper trading statistics."""
        all_trades = []
        for account in self.accounts.values():
            all_trades.extend(account.trade_history)
        
        if not all_trades:
            return {
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "win_rate": 0,
                "total_pnl": 0,
                "avg_win": 0,
                "avg_loss": 0,
                "total_equity": self.get_total_equity(),
                "initial_equity": self.initial_balance * 2,
                "return_pct": 0
            }
        
        winning = [t for t in all_trades if t.realized_pnl > 0]
        losing = [t for t in all_trades if t.realized_pnl < 0]
        total_pnl = sum(t.realized_pnl for t in all_trades)
        
        initial_equity = self.initial_balance * 2
        current_equity = self.get_total_equity()
        
        return {
            "total_trades": len(all_trades),
            "winning_trades": len(winning),
            "losing_trades": len(losing),
            "win_rate": len(winning) / len(all_trades) * 100 if all_trades else 0,
            "total_pnl": total_pnl,
            "avg_win": sum(t.realized_pnl for t in winning) / len(winning) if winning else 0,
            "avg_loss": sum(t.realized_pnl for t in losing) / len(losing) if losing else 0,
            "total_equity": current_equity,
            "initial_equity": initial_equity,
            "return_pct": (current_equity - initial_equity) / initial_equity * 100
        }
    
    def reset(self) -> None:
        """Reset paper accounts to initial state."""
        for account in self.accounts.values():
            account.balance = self.initial_balance
            account.positions = []
            account.realized_pnl = 0.0
            account.trade_history = []
        
        self.logger.info("[PAPER] Accounts reset to initial state")

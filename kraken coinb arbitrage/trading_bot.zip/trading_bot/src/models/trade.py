"""
Trade models for tracking positions and P&L.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
import uuid


class TradeDirection(str, Enum):
    """Trade direction."""
    LONG = "long"
    SHORT = "short"


class TradeStatus(str, Enum):
    """Trade lifecycle status."""
    PENDING = "pending"
    ENTRY_SUBMITTED = "entry_submitted"
    ENTRY_FILLED = "entry_filled"
    OPEN = "open"
    EXIT_SUBMITTED = "exit_submitted"
    CLOSED = "closed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class ExitReason(str, Enum):
    """Reason for trade exit."""
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"
    MANUAL = "manual"
    SYSTEM = "system"


@dataclass
class Trade:
    """
    Represents a complete trade lifecycle from entry to exit.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    signal_id: str = ""
    exchange: str = ""
    symbol: str = ""
    direction: TradeDirection = TradeDirection.LONG
    status: TradeStatus = TradeStatus.PENDING
    
    # Entry details
    entry_price: float = 0.0
    entry_amount: float = 0.0
    entry_value: float = 0.0  # entry_price * entry_amount
    entry_order_id: Optional[str] = None
    entry_time: Optional[datetime] = None
    entry_fee: float = 0.0
    
    # Exit details
    exit_price: Optional[float] = None
    exit_amount: Optional[float] = None
    exit_value: Optional[float] = None
    exit_order_id: Optional[str] = None
    exit_time: Optional[datetime] = None
    exit_fee: float = 0.0
    exit_reason: Optional[ExitReason] = None
    
    # Risk levels
    stop_loss_price: float = 0.0
    take_profit_price: float = 0.0
    
    # OCO order tracking
    oco_order_id: Optional[str] = None
    
    # P&L
    realized_pnl: float = 0.0
    realized_pnl_pct: float = 0.0
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    notes: str = ""
    paper_trade: bool = False
    
    @property
    def is_open(self) -> bool:
        return self.status in [TradeStatus.OPEN, TradeStatus.ENTRY_FILLED]
    
    @property
    def is_closed(self) -> bool:
        return self.status == TradeStatus.CLOSED
    
    @property
    def is_long(self) -> bool:
        return self.direction == TradeDirection.LONG
    
    @property
    def is_short(self) -> bool:
        return self.direction == TradeDirection.SHORT
    
    @property
    def total_fees(self) -> float:
        return self.entry_fee + self.exit_fee
    
    def calculate_stop_loss(self, stop_loss_pct: float) -> float:
        """Calculate stop loss price based on entry and direction."""
        if self.is_long:
            return self.entry_price * (1 - stop_loss_pct / 100)
        else:
            return self.entry_price * (1 + stop_loss_pct / 100)
    
    def calculate_take_profit(self, take_profit_pct: float) -> float:
        """Calculate take profit price based on entry and direction."""
        if self.is_long:
            return self.entry_price * (1 + take_profit_pct / 100)
        else:
            return self.entry_price * (1 - take_profit_pct / 100)
    
    def set_exit_levels(self, stop_loss_pct: float, take_profit_pct: float) -> None:
        """Set both SL and TP levels."""
        self.stop_loss_price = self.calculate_stop_loss(stop_loss_pct)
        self.take_profit_price = self.calculate_take_profit(take_profit_pct)
    
    def calculate_pnl(self) -> None:
        """Calculate realized P&L when trade is closed."""
        if self.exit_price is None or self.exit_amount is None:
            return
        
        self.exit_value = self.exit_price * self.exit_amount
        
        if self.is_long:
            self.realized_pnl = self.exit_value - self.entry_value - self.total_fees
        else:
            self.realized_pnl = self.entry_value - self.exit_value - self.total_fees
        
        if self.entry_value > 0:
            self.realized_pnl_pct = (self.realized_pnl / self.entry_value) * 100
    
    def close(self, exit_price: float, exit_amount: float, exit_reason: ExitReason, 
              exit_fee: float = 0.0) -> None:
        """Close the trade with exit details."""
        self.exit_price = exit_price
        self.exit_amount = exit_amount
        self.exit_reason = exit_reason
        self.exit_fee = exit_fee
        self.exit_time = datetime.utcnow()
        self.status = TradeStatus.CLOSED
        self.updated_at = datetime.utcnow()
        self.calculate_pnl()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert trade to dictionary."""
        return {
            "id": self.id,
            "signal_id": self.signal_id,
            "exchange": self.exchange,
            "symbol": self.symbol,
            "direction": self.direction.value,
            "status": self.status.value,
            "entry_price": self.entry_price,
            "entry_amount": self.entry_amount,
            "entry_value": self.entry_value,
            "entry_order_id": self.entry_order_id,
            "entry_time": self.entry_time.isoformat() if self.entry_time else None,
            "entry_fee": self.entry_fee,
            "exit_price": self.exit_price,
            "exit_amount": self.exit_amount,
            "exit_value": self.exit_value,
            "exit_order_id": self.exit_order_id,
            "exit_time": self.exit_time.isoformat() if self.exit_time else None,
            "exit_fee": self.exit_fee,
            "exit_reason": self.exit_reason.value if self.exit_reason else None,
            "stop_loss_price": self.stop_loss_price,
            "take_profit_price": self.take_profit_price,
            "oco_order_id": self.oco_order_id,
            "realized_pnl": self.realized_pnl,
            "realized_pnl_pct": self.realized_pnl_pct,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "notes": self.notes,
            "paper_trade": self.paper_trade
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Trade":
        """Create trade from dictionary."""
        trade = cls(
            id=data.get("id", str(uuid.uuid4())),
            signal_id=data.get("signal_id", ""),
            exchange=data.get("exchange", ""),
            symbol=data.get("symbol", ""),
            direction=TradeDirection(data.get("direction", "long")),
            status=TradeStatus(data.get("status", "pending")),
            entry_price=float(data.get("entry_price", 0)),
            entry_amount=float(data.get("entry_amount", 0)),
            entry_value=float(data.get("entry_value", 0)),
            entry_order_id=data.get("entry_order_id"),
            entry_fee=float(data.get("entry_fee", 0)),
            stop_loss_price=float(data.get("stop_loss_price", 0)),
            take_profit_price=float(data.get("take_profit_price", 0)),
            oco_order_id=data.get("oco_order_id"),
            realized_pnl=float(data.get("realized_pnl", 0)),
            realized_pnl_pct=float(data.get("realized_pnl_pct", 0)),
            notes=data.get("notes", ""),
            paper_trade=data.get("paper_trade", False)
        )
        
        if data.get("entry_time"):
            trade.entry_time = datetime.fromisoformat(data["entry_time"])
        if data.get("exit_price"):
            trade.exit_price = float(data["exit_price"])
        if data.get("exit_amount"):
            trade.exit_amount = float(data["exit_amount"])
        if data.get("exit_value"):
            trade.exit_value = float(data["exit_value"])
        if data.get("exit_order_id"):
            trade.exit_order_id = data["exit_order_id"]
        if data.get("exit_time"):
            trade.exit_time = datetime.fromisoformat(data["exit_time"])
        if data.get("exit_fee"):
            trade.exit_fee = float(data["exit_fee"])
        if data.get("exit_reason"):
            trade.exit_reason = ExitReason(data["exit_reason"])
        if data.get("created_at"):
            trade.created_at = datetime.fromisoformat(data["created_at"])
        if data.get("updated_at"):
            trade.updated_at = datetime.fromisoformat(data["updated_at"])
        
        return trade


@dataclass
class DailyTradeCounter:
    """Track daily trade count for max trades per day enforcement."""
    date: str  # YYYY-MM-DD format in UTC
    count: int = 0
    trade_ids: List[str] = field(default_factory=list)
    
    def increment(self, trade_id: str) -> None:
        """Increment trade count for the day."""
        self.count += 1
        self.trade_ids.append(trade_id)
    
    def can_trade(self, max_trades: int) -> bool:
        """Check if more trades are allowed today."""
        return self.count < max_trades
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date,
            "count": self.count,
            "trade_ids": self.trade_ids
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DailyTradeCounter":
        return cls(
            date=data["date"],
            count=data.get("count", 0),
            trade_ids=data.get("trade_ids", [])
        )

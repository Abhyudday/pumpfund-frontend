"""
Signal models for TradingView webhook alerts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional
import hashlib
import json


class SignalType(str, Enum):
    """Type of trading signal."""
    BUY = "BUY"
    SELL = "SELL"


class BraidColor(str, Enum):
    """Braid Filter color indicator."""
    GREEN = "green"
    RED = "red"
    GRAY = "gray"


@dataclass
class Signal:
    """
    Trading signal received from TradingView webhook.
    """
    signal_type: SignalType
    symbol: str
    timestamp: datetime
    close_price: float
    adx: float
    braid_color: BraidColor
    timeframe: str = "15m"
    bar_close: bool = True
    extra: Dict[str, Any] = field(default_factory=dict)
    raw_payload: Optional[str] = None
    
    @property
    def unique_id(self) -> str:
        """Generate unique ID for deduplication."""
        data = f"{self.signal_type.value}:{self.symbol}:{self.timestamp.isoformat()}:{self.close_price}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    @property
    def is_buy(self) -> bool:
        return self.signal_type == SignalType.BUY
    
    @property
    def is_sell(self) -> bool:
        return self.signal_type == SignalType.SELL
    
    @classmethod
    def from_webhook_payload(cls, payload: Dict[str, Any]) -> "Signal":
        """
        Parse signal from TradingView webhook JSON payload.
        
        Expected format:
        {
            "signal": "BUY" | "SELL",
            "symbol": "BTCUSD",
            "time": "2026-01-21T12:45:00Z",
            "close": 42350.12,
            "adx": 24.7,
            "braid_color": "green" | "red",
            "bar_close": true,
            "extra": {...}
        }
        """
        signal_str = payload.get("signal", "").upper()
        if signal_str not in [s.value for s in SignalType]:
            raise ValueError(f"Invalid signal type: {signal_str}")
        
        braid_str = payload.get("braid_color", "gray").lower()
        if braid_str not in [b.value for b in BraidColor]:
            raise ValueError(f"Invalid braid color: {braid_str}")
        
        time_str = payload.get("time")
        if time_str:
            timestamp = datetime.fromisoformat(time_str.replace("Z", "+00:00"))
        else:
            timestamp = datetime.utcnow()
        
        return cls(
            signal_type=SignalType(signal_str),
            symbol=payload.get("symbol", "BTCUSD"),
            timestamp=timestamp,
            close_price=float(payload.get("close", 0)),
            adx=float(payload.get("adx", 0)),
            braid_color=BraidColor(braid_str),
            timeframe=payload.get("tf", "15m"),
            bar_close=payload.get("bar_close", True),
            extra=payload.get("extra", {}),
            raw_payload=json.dumps(payload)
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert signal to dictionary."""
        return {
            "unique_id": self.unique_id,
            "signal_type": self.signal_type.value,
            "symbol": self.symbol,
            "timestamp": self.timestamp.isoformat(),
            "close_price": self.close_price,
            "adx": self.adx,
            "braid_color": self.braid_color.value,
            "timeframe": self.timeframe,
            "bar_close": self.bar_close,
            "extra": self.extra
        }
    
    def validate_strength(self, baseline: float) -> bool:
        """Check if ADX strength is above baseline."""
        return self.adx > baseline
    
    def validate_braid_alignment(self) -> bool:
        """
        Validate braid alignment matches signal direction.
        BUY requires green, SELL requires red.
        """
        if self.is_buy:
            return self.braid_color == BraidColor.GREEN
        elif self.is_sell:
            return self.braid_color == BraidColor.RED
        return False

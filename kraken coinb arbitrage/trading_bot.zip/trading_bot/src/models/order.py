"""
Order models for exchange operations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
import uuid


class OrderType(str, Enum):
    """Order type."""
    MARKET = "market"
    LIMIT = "limit"
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"
    STOP_LOSS_LIMIT = "stop_loss_limit"
    TAKE_PROFIT_LIMIT = "take_profit_limit"


class OrderSide(str, Enum):
    """Order side."""
    BUY = "buy"
    SELL = "sell"


class OrderStatus(str, Enum):
    """Order status."""
    PENDING = "pending"
    SUBMITTED = "submitted"
    OPEN = "open"
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    FAILED = "failed"


@dataclass
class Order:
    """Single order representation."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    exchange: str = ""
    symbol: str = ""
    order_type: OrderType = OrderType.MARKET
    side: OrderSide = OrderSide.BUY
    amount: float = 0.0
    price: Optional[float] = None
    stop_price: Optional[float] = None
    status: OrderStatus = OrderStatus.PENDING
    exchange_order_id: Optional[str] = None
    filled_amount: float = 0.0
    filled_price: Optional[float] = None
    fee: float = 0.0
    fee_currency: str = "USD"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    raw_response: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    
    @property
    def is_filled(self) -> bool:
        return self.status == OrderStatus.FILLED
    
    @property
    def is_open(self) -> bool:
        return self.status in [OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED, OrderStatus.SUBMITTED]
    
    @property
    def is_terminal(self) -> bool:
        return self.status in [
            OrderStatus.FILLED,
            OrderStatus.CANCELLED,
            OrderStatus.REJECTED,
            OrderStatus.EXPIRED,
            OrderStatus.FAILED
        ]
    
    @property
    def remaining_amount(self) -> float:
        return max(0, self.amount - self.filled_amount)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert order to dictionary."""
        return {
            "id": self.id,
            "exchange": self.exchange,
            "symbol": self.symbol,
            "order_type": self.order_type.value,
            "side": self.side.value,
            "amount": self.amount,
            "price": self.price,
            "stop_price": self.stop_price,
            "status": self.status.value,
            "exchange_order_id": self.exchange_order_id,
            "filled_amount": self.filled_amount,
            "filled_price": self.filled_price,
            "fee": self.fee,
            "fee_currency": self.fee_currency,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "error_message": self.error_message
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Order":
        """Create order from dictionary."""
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            exchange=data.get("exchange", ""),
            symbol=data.get("symbol", ""),
            order_type=OrderType(data.get("order_type", "market")),
            side=OrderSide(data.get("side", "buy")),
            amount=float(data.get("amount", 0)),
            price=float(data["price"]) if data.get("price") else None,
            stop_price=float(data["stop_price"]) if data.get("stop_price") else None,
            status=OrderStatus(data.get("status", "pending")),
            exchange_order_id=data.get("exchange_order_id"),
            filled_amount=float(data.get("filled_amount", 0)),
            filled_price=float(data["filled_price"]) if data.get("filled_price") else None,
            fee=float(data.get("fee", 0)),
            fee_currency=data.get("fee_currency", "USD"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.utcnow(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.utcnow(),
            error_message=data.get("error_message")
        )


@dataclass
class OCOOrder:
    """
    One-Cancels-Other order for Stop Loss and Take Profit.
    When one triggers, the other is automatically cancelled.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    trade_id: str = ""
    exchange: str = ""
    symbol: str = ""
    entry_price: float = 0.0
    position_size: float = 0.0
    side: OrderSide = OrderSide.BUY  # Side of the original entry
    stop_loss_order: Optional[Order] = None
    take_profit_order: Optional[Order] = None
    status: str = "pending"  # pending, active, triggered, cancelled
    triggered_order: Optional[str] = None  # "stop_loss" or "take_profit"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def exit_side(self) -> OrderSide:
        """Get the side for exit orders (opposite of entry)."""
        return OrderSide.SELL if self.side == OrderSide.BUY else OrderSide.BUY
    
    @property
    def is_active(self) -> bool:
        return self.status == "active"
    
    @property
    def is_triggered(self) -> bool:
        return self.status == "triggered"
    
    def create_stop_loss(self, stop_price: float) -> Order:
        """Create stop loss order."""
        self.stop_loss_order = Order(
            exchange=self.exchange,
            symbol=self.symbol,
            order_type=OrderType.STOP_LOSS,
            side=self.exit_side,
            amount=self.position_size,
            stop_price=stop_price,
            status=OrderStatus.PENDING
        )
        return self.stop_loss_order
    
    def create_take_profit(self, take_profit_price: float) -> Order:
        """Create take profit order."""
        self.take_profit_order = Order(
            exchange=self.exchange,
            symbol=self.symbol,
            order_type=OrderType.TAKE_PROFIT,
            side=self.exit_side,
            amount=self.position_size,
            price=take_profit_price,
            status=OrderStatus.PENDING
        )
        return self.take_profit_order
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert OCO order to dictionary."""
        return {
            "id": self.id,
            "trade_id": self.trade_id,
            "exchange": self.exchange,
            "symbol": self.symbol,
            "entry_price": self.entry_price,
            "position_size": self.position_size,
            "side": self.side.value,
            "stop_loss_order": self.stop_loss_order.to_dict() if self.stop_loss_order else None,
            "take_profit_order": self.take_profit_order.to_dict() if self.take_profit_order else None,
            "status": self.status,
            "triggered_order": self.triggered_order,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OCOOrder":
        """Create OCO order from dictionary."""
        oco = cls(
            id=data.get("id", str(uuid.uuid4())),
            trade_id=data.get("trade_id", ""),
            exchange=data.get("exchange", ""),
            symbol=data.get("symbol", ""),
            entry_price=float(data.get("entry_price", 0)),
            position_size=float(data.get("position_size", 0)),
            side=OrderSide(data.get("side", "buy")),
            status=data.get("status", "pending"),
            triggered_order=data.get("triggered_order"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.utcnow(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.utcnow()
        )
        
        if data.get("stop_loss_order"):
            oco.stop_loss_order = Order.from_dict(data["stop_loss_order"])
        if data.get("take_profit_order"):
            oco.take_profit_order = Order.from_dict(data["take_profit_order"])
        
        return oco

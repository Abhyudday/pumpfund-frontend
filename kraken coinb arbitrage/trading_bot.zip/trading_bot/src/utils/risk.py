"""
Risk calculation module for position sizing.
Implements exact risk rules as specified.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
import logging

from ..config import Settings

logger = logging.getLogger(__name__)


@dataclass
class PositionSizeResult:
    """Result of position size calculation."""
    position_size: float  # Amount of BTC to buy/sell
    position_value: float  # USD value of position
    risk_amount: float  # USD amount at risk
    risk_percentage: float  # Risk % used
    stop_loss_price: float
    take_profit_price: float
    entry_price: float
    is_valid: bool = True
    rejection_reason: Optional[str] = None


class RiskCalculator:
    """
    Calculate position sizes based on account equity and risk rules.
    
    Risk Rules:
    - If equity < $100,000: risk = 2% per trade
    - If equity >= $100,000: risk = 1% per trade (locked forever)
    - Stop loss = 6% from entry
    - Position size = risk_amount / (stop_loss_pct * entry_price)
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self._risk_locked_to_1pct = False
    
    def get_risk_percentage(self, equity: float) -> float:
        """
        Get the risk percentage based on account equity.
        Once equity >= 100k, 1% risk is locked forever.
        """
        if self._risk_locked_to_1pct:
            return self.settings.risk.risk_pct_above_threshold / 100
        
        if equity >= self.settings.risk.equity_threshold:
            self._risk_locked_to_1pct = True
            logger.info(
                f"Risk locked to 1%: equity ${equity:,.2f} >= threshold "
                f"${self.settings.risk.equity_threshold:,.2f}"
            )
            return self.settings.risk.risk_pct_above_threshold / 100
        
        return self.settings.risk.risk_pct_below_threshold / 100
    
    def is_risk_locked(self) -> bool:
        """Check if risk is locked to 1%."""
        return self._risk_locked_to_1pct
    
    def set_risk_locked(self, locked: bool) -> None:
        """Set the risk lock state (for persistence)."""
        self._risk_locked_to_1pct = locked
    
    def calculate_position_size(
        self,
        equity: float,
        entry_price: float,
        is_long: bool = True,
        min_order_size: float = 0.0001  # Minimum BTC order size
    ) -> PositionSizeResult:
        """
        Calculate position size based on risk parameters.
        
        Formula:
        position_size = risk_amount / (stop_loss_pct * entry_price)
        
        Where:
        - risk_amount = equity * risk_percentage
        - stop_loss_pct = 6% (configurable)
        
        Args:
            equity: Total account equity in USD
            entry_price: Expected entry price
            is_long: True for long, False for short
            min_order_size: Minimum order size for the exchange
        
        Returns:
            PositionSizeResult with calculated values
        """
        if equity <= 0:
            return PositionSizeResult(
                position_size=0,
                position_value=0,
                risk_amount=0,
                risk_percentage=0,
                stop_loss_price=0,
                take_profit_price=0,
                entry_price=entry_price,
                is_valid=False,
                rejection_reason="Invalid equity: must be positive"
            )
        
        if entry_price <= 0:
            return PositionSizeResult(
                position_size=0,
                position_value=0,
                risk_amount=0,
                risk_percentage=0,
                stop_loss_price=0,
                take_profit_price=0,
                entry_price=entry_price,
                is_valid=False,
                rejection_reason="Invalid entry price: must be positive"
            )
        
        # Get risk percentage (2% or 1%)
        risk_pct = self.get_risk_percentage(equity)
        
        # Calculate risk amount in USD
        risk_amount = equity * risk_pct
        
        # Calculate stop loss and take profit prices
        stop_loss_pct = self.settings.risk.stop_loss_pct / 100
        take_profit_pct = self.settings.risk.take_profit_pct / 100
        
        if is_long:
            stop_loss_price = entry_price * (1 - stop_loss_pct)
            take_profit_price = entry_price * (1 + take_profit_pct)
        else:
            stop_loss_price = entry_price * (1 + stop_loss_pct)
            take_profit_price = entry_price * (1 - take_profit_pct)
        
        # Calculate position size
        # position_size = risk_amount / (stop_loss_pct * entry_price)
        position_size = risk_amount / (stop_loss_pct * entry_price)
        
        # Calculate position value
        position_value = position_size * entry_price
        
        # Validate minimum order size
        if position_size < min_order_size:
            return PositionSizeResult(
                position_size=position_size,
                position_value=position_value,
                risk_amount=risk_amount,
                risk_percentage=risk_pct,
                stop_loss_price=stop_loss_price,
                take_profit_price=take_profit_price,
                entry_price=entry_price,
                is_valid=False,
                rejection_reason=f"Position size {position_size:.8f} below minimum {min_order_size}"
            )
        
        logger.info(
            f"Position calculated: size={position_size:.8f} BTC, "
            f"value=${position_value:,.2f}, risk=${risk_amount:,.2f} ({risk_pct*100:.1f}%), "
            f"SL=${stop_loss_price:,.2f}, TP=${take_profit_price:,.2f}"
        )
        
        return PositionSizeResult(
            position_size=position_size,
            position_value=position_value,
            risk_amount=risk_amount,
            risk_percentage=risk_pct,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            entry_price=entry_price,
            is_valid=True
        )
    
    def validate_balance(
        self,
        required_value: float,
        available_balance: float,
        buffer_pct: float = 1.0  # 1% buffer for fees/slippage
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate that sufficient balance is available.
        
        Args:
            required_value: Required position value in USD
            available_balance: Available balance in USD
            buffer_pct: Buffer percentage for fees/slippage
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        required_with_buffer = required_value * (1 + buffer_pct / 100)
        
        if available_balance < required_with_buffer:
            return False, (
                f"Insufficient balance: required ${required_with_buffer:,.2f} "
                f"(including {buffer_pct}% buffer), available ${available_balance:,.2f}"
            )
        
        return True, None
    
    def calculate_slippage_adjusted_size(
        self,
        position_size: float,
        expected_price: float,
        actual_price: float,
        max_slippage_pct: Optional[float] = None
    ) -> Tuple[float, bool, Optional[str]]:
        """
        Adjust position size for slippage and validate within tolerance.
        
        Args:
            position_size: Original calculated position size
            expected_price: Expected entry price from signal
            actual_price: Actual current market price
            max_slippage_pct: Maximum allowed slippage percentage
        
        Returns:
            Tuple of (adjusted_size, is_valid, error_message)
        """
        if max_slippage_pct is None:
            max_slippage_pct = self.settings.risk.max_slippage_pct
        
        slippage_pct = abs(actual_price - expected_price) / expected_price * 100
        
        if slippage_pct > max_slippage_pct:
            return 0, False, (
                f"Slippage {slippage_pct:.2f}% exceeds maximum {max_slippage_pct:.2f}%"
            )
        
        # Adjust position size to maintain risk at actual price
        adjusted_size = position_size * (expected_price / actual_price)
        
        return adjusted_size, True, None


def calculate_position_size_simple(
    equity: float,
    entry_price: float,
    stop_loss_pct: float = 6.0,
    risk_pct: float = 2.0
) -> float:
    """
    Simple position size calculation for CLI/testing.
    
    Args:
        equity: Account equity in USD
        entry_price: Entry price
        stop_loss_pct: Stop loss percentage (default 6%)
        risk_pct: Risk percentage (default 2%)
    
    Returns:
        Position size in base currency (BTC)
    """
    risk_amount = equity * (risk_pct / 100)
    position_size = risk_amount / ((stop_loss_pct / 100) * entry_price)
    return position_size

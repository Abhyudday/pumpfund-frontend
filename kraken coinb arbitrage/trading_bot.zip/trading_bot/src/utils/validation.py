"""
Signal and webhook validation utilities.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
from dataclasses import dataclass
from datetime import datetime, time, timezone
from typing import Any, Dict, Optional, Set, Tuple

from ..config import Settings
from ..models.signal import BraidColor, Signal, SignalType

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of signal validation."""
    is_valid: bool
    signal: Optional[Signal] = None
    rejection_reason: Optional[str] = None
    warnings: list = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


class SignalValidator:
    """
    Validates incoming TradingView webhook signals.
    
    Validation checks:
    1. HMAC signature verification
    2. Bar close confirmation
    3. Blocked window check (22:00-00:00 UTC)
    4. Daily trade limit check
    5. ADX strength above baseline
    6. Braid color alignment with signal
    7. Duplicate signal detection
    8. Price tolerance with current market
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self._processed_signals: Set[str] = set()
        self._max_processed_cache = 10000
    
    def verify_signature(self, payload: bytes, signature: str) -> bool:
        """
        Verify HMAC-SHA256 signature of webhook payload.
        
        Args:
            payload: Raw request body bytes
            signature: Signature from X-Signature header
        
        Returns:
            True if signature is valid
        """
        if not self.settings.webhook_secret:
            logger.warning("No webhook secret configured, skipping signature verification")
            return True
        
        expected_sig = hmac.new(
            self.settings.webhook_secret.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(expected_sig, signature)
    
    def is_in_blocked_window(self, timestamp: Optional[datetime] = None) -> bool:
        """
        Check if the given timestamp falls within the blocked trading window.
        Default blocked window: 22:00 to 00:00 UTC
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)
        
        current_time = timestamp.time()
        
        blocked_start = time(
            self.settings.trading_window.blocked_start_hour,
            self.settings.trading_window.blocked_start_minute
        )
        blocked_end = time(
            self.settings.trading_window.blocked_end_hour,
            self.settings.trading_window.blocked_end_minute
        )
        
        # Handle overnight window (e.g., 22:00 to 00:00)
        if blocked_start > blocked_end:
            return current_time >= blocked_start or current_time < blocked_end
        else:
            return blocked_start <= current_time < blocked_end
    
    def check_strength(self, adx_value: float) -> bool:
        """Check if ADX strength is above baseline."""
        return adx_value > self.settings.strength.baseline
    
    def check_braid_alignment(self, signal_type: SignalType, braid_color: BraidColor) -> bool:
        """
        Verify braid color aligns with signal direction.
        BUY requires green, SELL requires red.
        """
        if signal_type == SignalType.BUY:
            return braid_color == BraidColor.GREEN
        elif signal_type == SignalType.SELL:
            return braid_color == BraidColor.RED
        return False
    
    def is_duplicate(self, signal_id: str) -> bool:
        """Check if signal has already been processed."""
        return signal_id in self._processed_signals
    
    def mark_processed(self, signal_id: str) -> None:
        """Mark signal as processed for deduplication."""
        self._processed_signals.add(signal_id)
        
        # Prevent memory bloat
        if len(self._processed_signals) > self._max_processed_cache:
            # Remove oldest half
            to_remove = list(self._processed_signals)[:self._max_processed_cache // 2]
            for sig_id in to_remove:
                self._processed_signals.discard(sig_id)
    
    def validate_price_tolerance(
        self,
        signal_price: float,
        market_price: float,
        tolerance_pct: Optional[float] = None
    ) -> Tuple[bool, float]:
        """
        Validate that signal price is within tolerance of market price.
        
        Returns:
            Tuple of (is_valid, price_deviation_pct)
        """
        if tolerance_pct is None:
            tolerance_pct = self.settings.price_tolerance_pct
        
        if signal_price <= 0 or market_price <= 0:
            return False, 100.0
        
        deviation_pct = abs(signal_price - market_price) / market_price * 100
        return deviation_pct <= tolerance_pct, deviation_pct
    
    def validate_signal(
        self,
        payload: Dict[str, Any],
        raw_body: Optional[bytes] = None,
        signature: Optional[str] = None,
        current_trades_today: int = 0,
        market_prices: Optional[Dict[str, float]] = None
    ) -> ValidationResult:
        """
        Perform full validation of incoming signal.
        
        Args:
            payload: Parsed JSON payload
            raw_body: Raw request body for signature verification
            signature: HMAC signature header
            current_trades_today: Number of trades already executed today
            market_prices: Current market prices from exchanges for tolerance check
        
        Returns:
            ValidationResult with signal or rejection reason
        """
        warnings = []
        
        # 1. Verify signature if provided
        if raw_body and signature:
            if not self.verify_signature(raw_body, signature):
                return ValidationResult(
                    is_valid=False,
                    rejection_reason="Invalid webhook signature"
                )
        elif self.settings.webhook_secret and not signature:
            logger.warning("Webhook secret configured but no signature provided")
            warnings.append("Missing signature header")
        
        # 2. Parse signal
        try:
            signal = Signal.from_webhook_payload(payload)
        except (ValueError, KeyError) as e:
            return ValidationResult(
                is_valid=False,
                rejection_reason=f"Invalid signal payload: {str(e)}"
            )
        
        # 3. Check bar close confirmation
        if not signal.bar_close:
            return ValidationResult(
                is_valid=False,
                rejection_reason="Signal must be from bar close (bar_close=true required)"
            )
        
        # 4. Check blocked window
        if self.is_in_blocked_window(signal.timestamp):
            return ValidationResult(
                is_valid=False,
                signal=signal,
                rejection_reason="Signal rejected: within blocked trading window (22:00-00:00 UTC)"
            )
        
        # 5. Check daily trade limit
        max_trades = self.settings.trading_window.max_trades_per_day
        if current_trades_today >= max_trades:
            return ValidationResult(
                is_valid=False,
                signal=signal,
                rejection_reason=f"Daily trade limit reached: {current_trades_today}/{max_trades}"
            )
        
        # 6. Check strength indicator (ADX)
        if not self.check_strength(signal.adx):
            return ValidationResult(
                is_valid=False,
                signal=signal,
                rejection_reason=(
                    f"Strength below baseline: ADX={signal.adx:.2f}, "
                    f"required>{self.settings.strength.baseline}"
                )
            )
        
        # 7. Check braid alignment
        if not self.check_braid_alignment(signal.signal_type, signal.braid_color):
            expected_color = "green" if signal.signal_type == SignalType.BUY else "red"
            return ValidationResult(
                is_valid=False,
                signal=signal,
                rejection_reason=(
                    f"Braid color mismatch: {signal.braid_color.value} for {signal.signal_type.value}, "
                    f"expected {expected_color}"
                )
            )
        
        # 8. Check for duplicate
        if self.is_duplicate(signal.unique_id):
            return ValidationResult(
                is_valid=False,
                signal=signal,
                rejection_reason=f"Duplicate signal rejected: {signal.unique_id}"
            )
        
        # 9. Validate price tolerance with market (if market prices provided)
        if market_prices:
            for exchange, market_price in market_prices.items():
                is_valid, deviation = self.validate_price_tolerance(
                    signal.close_price, market_price
                )
                if not is_valid:
                    warnings.append(
                        f"Price deviation on {exchange}: {deviation:.2f}% "
                        f"(signal: {signal.close_price}, market: {market_price})"
                    )
        
        # Mark as processed
        self.mark_processed(signal.unique_id)
        
        logger.info(
            f"Signal validated: {signal.signal_type.value} @ ${signal.close_price:,.2f}, "
            f"ADX={signal.adx:.2f}, braid={signal.braid_color.value}"
        )
        
        return ValidationResult(
            is_valid=True,
            signal=signal,
            warnings=warnings
        )


def create_webhook_signature(payload: Dict[str, Any], secret: str) -> str:
    """
    Create HMAC-SHA256 signature for webhook payload.
    Useful for testing and the simulate_signals tool.
    """
    body = json.dumps(payload, separators=(",", ":")).encode()
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()

#!/usr/bin/env python3
"""
CLI tool for trading bot management.

Usage:
    python scripts/cli.py status
    python scripts/cli.py equity
    python scripts/cli.py position-size --equity 10000 --price 50000
    python scripts/cli.py trades --limit 10
    python scripts/cli.py backtest --data data/btc_15m.csv
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

load_dotenv()


def cmd_status(args):
    """Show bot status."""
    from src.services.database import Database
    from src.config import get_settings
    
    settings = get_settings()
    db = Database()
    
    open_trades = db.get_open_trades()
    trades_today = db.get_daily_trade_count()
    stats = db.get_trade_statistics()
    
    print("\n" + "="*50)
    print("TRADING BOT STATUS")
    print("="*50)
    print(f"Mode: {settings.mode.value}")
    print(f"Paper Trading: {settings.paper_trading}")
    print(f"Risk Locked to 1%: {db.is_risk_locked()}")
    print(f"\nOpen Trades: {len(open_trades)}")
    print(f"Trades Today: {trades_today}/{settings.trading_window.max_trades_per_day}")
    print(f"\nAll-time Statistics:")
    print(f"  Total Trades: {stats['total_trades']}")
    print(f"  Win Rate: {stats['win_rate']:.1f}%")
    print(f"  Total P&L: ${stats['total_pnl']:,.2f}")
    print("="*50 + "\n")


def cmd_equity(args):
    """Show account equity."""
    from src.config import get_settings
    
    settings = get_settings()
    
    if settings.paper_trading:
        print("\n[PAPER MODE] Simulated equity:")
        print(f"  Coinbase: $10,000.00")
        print(f"  Kraken: $10,000.00")
        print(f"  Total: $20,000.00")
        return
    
    async def fetch_equity():
        from src.connectors.manager import ExchangeManager
        
        manager = ExchangeManager(settings)
        await manager.initialize()
        
        total, breakdown = await manager.fetch_total_equity()
        
        print(f"\nAccount Equity:")
        for exchange, equity in breakdown.items():
            print(f"  {exchange.title()}: ${equity:,.2f}")
        print(f"  Total: ${total:,.2f}")
        
        await manager.close()
    
    asyncio.run(fetch_equity())


def cmd_position_size(args):
    """Calculate position size."""
    from src.config import get_settings
    from src.utils.risk import RiskCalculator
    
    settings = get_settings()
    calculator = RiskCalculator(settings)
    
    if args.risk_locked:
        calculator.set_risk_locked(True)
    
    result = calculator.calculate_position_size(
        equity=args.equity,
        entry_price=args.price,
        is_long=args.direction == "long"
    )
    
    print("\n" + "="*50)
    print("POSITION SIZE CALCULATION")
    print("="*50)
    print(f"Equity: ${args.equity:,.2f}")
    print(f"Entry Price: ${args.price:,.2f}")
    print(f"Direction: {args.direction.upper()}")
    print(f"\nRisk Percentage: {result.risk_percentage * 100:.1f}%")
    print(f"Risk Amount: ${result.risk_amount:,.2f}")
    print(f"\nPosition Size: {result.position_size:.8f} BTC")
    print(f"Position Value: ${result.position_value:,.2f}")
    print(f"\nStop Loss: ${result.stop_loss_price:,.2f}")
    print(f"Take Profit: ${result.take_profit_price:,.2f}")
    
    if not result.is_valid:
        print(f"\n⚠️  INVALID: {result.rejection_reason}")
    
    print("="*50 + "\n")


def cmd_trades(args):
    """List recent trades."""
    from src.services.database import Database
    
    db = Database()
    
    if args.status:
        trades = db.get_trades_by_status(args.status)[:args.limit]
    else:
        trades = db.get_recent_trades(args.limit)
    
    print(f"\n{'='*80}")
    print(f"{'ID':<12} {'Exchange':<10} {'Dir':<6} {'Entry':<12} {'Exit':<12} {'P&L':<12} {'Status':<10}")
    print(f"{'='*80}")
    
    for t in trades:
        exit_str = f"${t.exit_price:,.0f}" if t.exit_price else "-"
        pnl_str = f"${t.realized_pnl:,.2f}" if t.realized_pnl else "-"
        status = t.status if isinstance(t.status, str) else t.status.value
        
        print(f"{t.id[:10]:<12} {t.exchange:<10} {t.direction.value:<6} "
              f"${t.entry_price:,.0f:<11} {exit_str:<12} {pnl_str:<12} {status:<10}")
    
    print(f"{'='*80}\n")


def cmd_backtest(args):
    """Run backtest on historical data."""
    from src.backtester.data import load_ohlcv_from_csv, generate_sample_data
    from src.backtester.engine import Backtester, BacktestConfig
    
    # Load data
    if args.data:
        data = load_ohlcv_from_csv(args.data)
    else:
        print("Generating sample data for demo...")
        data = generate_sample_data(num_candles=args.candles or 1000)
    
    # Configure
    config = BacktestConfig(
        initial_equity=args.equity,
        stop_loss_pct=args.stop_loss,
        take_profit_pct=args.take_profit,
        risk_pct=args.risk,
        max_trades_per_day=args.max_trades
    )
    
    # Run
    print(f"\nRunning backtest on {len(data)} candles...")
    
    backtester = Backtester(config)
    metrics, trades = backtester.run(data)
    
    # Output
    print(metrics.summary())
    
    if args.output:
        backtester.export_results(args.output, metrics)
        print(f"Results exported to {args.output}")


def cmd_optimize(args):
    """Run parameter optimization."""
    from src.backtester.data import load_ohlcv_from_csv, generate_sample_data
    from src.backtester.engine import run_parameter_optimization
    
    # Load data
    if args.data:
        data = load_ohlcv_from_csv(args.data)
    else:
        data = generate_sample_data(num_candles=1000)
    
    # Define parameter ranges
    param_ranges = {
        "stop_loss_pct": [4.0, 5.0, 6.0, 7.0, 8.0],
        "take_profit_pct": [10.0, 12.0, 15.0, 18.0, 20.0],
        "risk_pct": [1.0, 2.0, 3.0]
    }
    
    print(f"\nRunning parameter optimization...")
    print(f"Testing {len(param_ranges['stop_loss_pct']) * len(param_ranges['take_profit_pct']) * len(param_ranges['risk_pct'])} combinations\n")
    
    results = run_parameter_optimization(data, param_ranges, args.equity)
    
    # Show top results
    print("\nTop 5 Parameter Sets by Sharpe Ratio:")
    print("-" * 60)
    
    for i, (params, metrics) in enumerate(results[:5], 1):
        print(f"\n{i}. Sharpe: {metrics.sharpe_ratio:.2f}, Return: {metrics.total_return_pct:.2f}%")
        print(f"   SL: {params['stop_loss_pct']}%, TP: {params['take_profit_pct']}%, Risk: {params['risk_pct']}%")
        print(f"   Trades: {metrics.total_trades}, Win Rate: {metrics.win_rate:.1f}%, Max DD: {metrics.max_drawdown_pct:.2f}%")


def main():
    parser = argparse.ArgumentParser(description="Trading Bot CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Status command
    subparsers.add_parser("status", help="Show bot status")
    
    # Equity command
    subparsers.add_parser("equity", help="Show account equity")
    
    # Position size command
    pos_parser = subparsers.add_parser("position-size", help="Calculate position size")
    pos_parser.add_argument("--equity", type=float, required=True, help="Account equity")
    pos_parser.add_argument("--price", type=float, required=True, help="Entry price")
    pos_parser.add_argument("--direction", default="long", choices=["long", "short"])
    pos_parser.add_argument("--risk-locked", action="store_true", help="Force 1% risk")
    
    # Trades command
    trades_parser = subparsers.add_parser("trades", help="List recent trades")
    trades_parser.add_argument("--limit", type=int, default=10)
    trades_parser.add_argument("--status", choices=["open", "closed", "failed"])
    
    # Backtest command
    bt_parser = subparsers.add_parser("backtest", help="Run backtest")
    bt_parser.add_argument("--data", help="Path to OHLCV CSV file")
    bt_parser.add_argument("--candles", type=int, help="Number of candles to generate if no data")
    bt_parser.add_argument("--equity", type=float, default=10000.0)
    bt_parser.add_argument("--stop-loss", type=float, default=6.0)
    bt_parser.add_argument("--take-profit", type=float, default=15.0)
    bt_parser.add_argument("--risk", type=float, default=2.0)
    bt_parser.add_argument("--max-trades", type=int, default=2)
    bt_parser.add_argument("--output", help="Output CSV path")
    
    # Optimize command
    opt_parser = subparsers.add_parser("optimize", help="Run parameter optimization")
    opt_parser.add_argument("--data", help="Path to OHLCV CSV file")
    opt_parser.add_argument("--equity", type=float, default=10000.0)
    
    args = parser.parse_args()
    
    if args.command == "status":
        cmd_status(args)
    elif args.command == "equity":
        cmd_equity(args)
    elif args.command == "position-size":
        cmd_position_size(args)
    elif args.command == "trades":
        cmd_trades(args)
    elif args.command == "backtest":
        cmd_backtest(args)
    elif args.command == "optimize":
        cmd_optimize(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

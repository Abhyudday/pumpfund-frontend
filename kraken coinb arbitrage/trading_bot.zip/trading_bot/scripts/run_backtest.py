#!/usr/bin/env python3
"""
Standalone backtest runner with visualization.

Usage:
    python scripts/run_backtest.py --candles 2000
    python scripts/run_backtest.py --data data/btc_15m.csv --output results/
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def main():
    parser = argparse.ArgumentParser(description="Run Backtest")
    parser.add_argument("--data", help="Path to OHLCV CSV file")
    parser.add_argument("--candles", type=int, default=1000, help="Generate N candles if no data")
    parser.add_argument("--equity", type=float, default=10000.0, help="Initial equity")
    parser.add_argument("--stop-loss", type=float, default=6.0, help="Stop loss %")
    parser.add_argument("--take-profit", type=float, default=15.0, help="Take profit %")
    parser.add_argument("--risk", type=float, default=2.0, help="Risk per trade %")
    parser.add_argument("--output", help="Output directory")
    parser.add_argument("--plot", action="store_true", help="Generate equity curve plot")
    
    args = parser.parse_args()
    
    from src.backtester.data import load_ohlcv_from_csv, generate_sample_data
    from src.backtester.engine import Backtester, BacktestConfig
    
    # Load or generate data
    if args.data:
        print(f"Loading data from {args.data}...")
        data = load_ohlcv_from_csv(args.data)
    else:
        print(f"Generating {args.candles} sample candles...")
        data = generate_sample_data(num_candles=args.candles, start_price=50000.0)
    
    print(f"Data range: {data.start_time} to {data.end_time}")
    print(f"Total candles: {len(data)}")
    
    # Configure backtest
    config = BacktestConfig(
        initial_equity=args.equity,
        stop_loss_pct=args.stop_loss,
        take_profit_pct=args.take_profit,
        risk_pct=args.risk,
        max_trades_per_day=2,
        commission_pct=0.1,
        slippage_pct=0.05
    )
    
    print(f"\nBacktest Configuration:")
    print(f"  Initial Equity: ${config.initial_equity:,.2f}")
    print(f"  Stop Loss: {config.stop_loss_pct}%")
    print(f"  Take Profit: {config.take_profit_pct}%")
    print(f"  Risk per Trade: {config.risk_pct}%")
    
    # Run backtest
    print("\nRunning backtest...")
    backtester = Backtester(config)
    metrics, trades = backtester.run(data)
    
    # Print results
    print(metrics.summary())
    
    # Export results
    if args.output:
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        csv_path = output_dir / "backtest_trades.csv"
        backtester.export_results(str(csv_path), metrics)
        print(f"Results exported to {csv_path}")
    
    # Plot equity curve
    if args.plot:
        try:
            import matplotlib.pyplot as plt
            
            plt.figure(figsize=(12, 6))
            plt.plot(metrics.equity_curve, linewidth=1)
            plt.axhline(y=config.initial_equity, color='gray', linestyle='--', alpha=0.5)
            plt.title("Equity Curve")
            plt.xlabel("Trade #")
            plt.ylabel("Equity ($)")
            plt.grid(True, alpha=0.3)
            
            if args.output:
                plot_path = Path(args.output) / "equity_curve.png"
                plt.savefig(plot_path, dpi=150, bbox_inches='tight')
                print(f"Plot saved to {plot_path}")
            else:
                plt.show()
            
            plt.close()
            
        except ImportError:
            print("\nNote: Install matplotlib for equity curve plots: pip install matplotlib")
    
    # Summary
    print("\n" + "="*50)
    print("BACKTEST COMPLETE")
    print("="*50)
    print(f"Total Trades: {metrics.total_trades}")
    print(f"Win Rate: {metrics.win_rate:.1f}%")
    print(f"Final Equity: ${metrics.final_equity:,.2f}")
    print(f"Total Return: {metrics.total_return_pct:.2f}%")
    print(f"Max Drawdown: {metrics.max_drawdown_pct:.2f}%")
    print(f"Sharpe Ratio: {metrics.sharpe_ratio:.2f}")
    print("="*50)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

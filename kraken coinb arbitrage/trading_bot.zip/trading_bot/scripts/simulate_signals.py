#!/usr/bin/env python3
"""
Simulate TradingView webhook signals for testing.

Usage:
    python scripts/simulate_signals.py --signal BUY --price 50000
    python scripts/simulate_signals.py --signal SELL --price 49000 --url http://localhost:8000
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import sys
from datetime import datetime, timezone
from typing import Optional

import httpx
from dotenv import load_dotenv

load_dotenv()


def create_signature(payload: dict, secret: str) -> str:
    """Create HMAC-SHA256 signature for payload."""
    body = json.dumps(payload, separators=(",", ":")).encode()
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def create_buy_signal(
    price: float,
    adx: float = 25.0,
    symbol: str = "BTCUSD"
) -> dict:
    """Create a BUY signal payload."""
    return {
        "signal": "BUY",
        "symbol": symbol,
        "time": datetime.now(timezone.utc).isoformat(),
        "close": price,
        "adx": adx,
        "braid_color": "green",
        "bar_close": True,
        "tf": "15m",
        "extra": {
            "period1": 3,
            "period2": 7,
            "period3": 14
        }
    }


def create_sell_signal(
    price: float,
    adx: float = 25.0,
    symbol: str = "BTCUSD"
) -> dict:
    """Create a SELL signal payload."""
    return {
        "signal": "SELL",
        "symbol": symbol,
        "time": datetime.now(timezone.utc).isoformat(),
        "close": price,
        "adx": adx,
        "braid_color": "red",
        "bar_close": True,
        "tf": "15m",
        "extra": {
            "period1": 3,
            "period2": 7,
            "period3": 14
        }
    }


def send_webhook(
    url: str,
    payload: dict,
    secret: Optional[str] = None,
    dry_run: bool = False
) -> dict:
    """Send webhook to the trading bot."""
    headers = {"Content-Type": "application/json"}
    
    if secret:
        signature = create_signature(payload, secret)
        headers["X-Signature"] = signature
    
    print(f"\n{'='*60}")
    print("WEBHOOK PAYLOAD:")
    print(json.dumps(payload, indent=2))
    print(f"{'='*60}")
    
    if dry_run:
        print("\n[DRY RUN] Would send to:", url)
        return {"dry_run": True, "payload": payload}
    
    try:
        response = httpx.post(
            url,
            json=payload,
            headers=headers,
            timeout=30.0
        )
        
        print(f"\nResponse Status: {response.status_code}")
        print(f"Response Body: {response.text}")
        
        return response.json()
    
    except httpx.RequestError as e:
        print(f"\nError sending webhook: {e}")
        return {"error": str(e)}


def main():
    parser = argparse.ArgumentParser(
        description="Simulate TradingView webhook signals"
    )
    parser.add_argument(
        "--signal",
        choices=["BUY", "SELL"],
        required=True,
        help="Signal type (BUY or SELL)"
    )
    parser.add_argument(
        "--price",
        type=float,
        required=True,
        help="Close price"
    )
    parser.add_argument(
        "--adx",
        type=float,
        default=25.0,
        help="ADX strength value (default: 25.0)"
    )
    parser.add_argument(
        "--symbol",
        default="BTCUSD",
        help="Trading symbol (default: BTCUSD)"
    )
    parser.add_argument(
        "--url",
        default="http://localhost:8000/webhook/tradingview",
        help="Webhook URL"
    )
    parser.add_argument(
        "--secret",
        default=os.getenv("WEBHOOK_SECRET"),
        help="Webhook secret for HMAC signature"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print payload without sending"
    )
    parser.add_argument(
        "--test-endpoint",
        action="store_true",
        help="Use /webhook/test endpoint instead"
    )
    
    args = parser.parse_args()
    
    # Create payload
    if args.signal == "BUY":
        payload = create_buy_signal(args.price, args.adx, args.symbol)
    else:
        payload = create_sell_signal(args.price, args.adx, args.symbol)
    
    # Adjust URL for test endpoint
    url = args.url
    if args.test_endpoint:
        url = url.replace("/tradingview", "/test")
    
    # Send webhook
    result = send_webhook(
        url=url,
        payload=payload,
        secret=args.secret,
        dry_run=args.dry_run
    )
    
    return 0 if result.get("success", False) or result.get("dry_run") else 1


if __name__ == "__main__":
    sys.exit(main())

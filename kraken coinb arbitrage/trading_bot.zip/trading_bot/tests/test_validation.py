"""
Unit tests for signal validation module.
"""
import json
from datetime import datetime, time, timezone
import pytest

from src.config import Settings, TradingWindowConfig, StrengthIndicatorConfig
from src.models.signal import BraidColor, Signal, SignalType
from src.utils.validation import SignalValidator, create_webhook_signature


class TestSignalValidator:
    """Tests for SignalValidator class."""
    
    @pytest.fixture
    def settings(self):
        """Create settings for testing."""
        settings = Settings()
        settings.webhook_secret = "test_secret_key"
        settings.trading_window = TradingWindowConfig(
            blocked_start_hour=22,
            blocked_start_minute=0,
            blocked_end_hour=0,
            blocked_end_minute=0,
            max_trades_per_day=2
        )
        settings.strength = StrengthIndicatorConfig(
            baseline=20.0,
            max_extension_pct=1.5
        )
        settings.price_tolerance_pct = 0.5
        return settings
    
    @pytest.fixture
    def validator(self, settings):
        """Create SignalValidator instance."""
        return SignalValidator(settings)
    
    @pytest.fixture
    def valid_buy_payload(self):
        """Create a valid BUY signal payload."""
        return {
            "signal": "BUY",
            "symbol": "BTCUSD",
            "time": "2026-01-21T12:00:00Z",
            "close": 50000.0,
            "adx": 25.0,
            "braid_color": "green",
            "bar_close": True,
            "tf": "15m"
        }
    
    @pytest.fixture
    def valid_sell_payload(self):
        """Create a valid SELL signal payload."""
        return {
            "signal": "SELL",
            "symbol": "BTCUSD",
            "time": "2026-01-21T12:00:00Z",
            "close": 50000.0,
            "adx": 25.0,
            "braid_color": "red",
            "bar_close": True,
            "tf": "15m"
        }
    
    def test_valid_buy_signal(self, validator, valid_buy_payload):
        """Test validation of valid BUY signal."""
        result = validator.validate_signal(valid_buy_payload)
        
        assert result.is_valid
        assert result.signal is not None
        assert result.signal.signal_type == SignalType.BUY
        assert result.rejection_reason is None
    
    def test_valid_sell_signal(self, validator, valid_sell_payload):
        """Test validation of valid SELL signal."""
        result = validator.validate_signal(valid_sell_payload)
        
        assert result.is_valid
        assert result.signal.signal_type == SignalType.SELL
    
    def test_signature_verification(self, validator, valid_buy_payload):
        """Test HMAC signature verification."""
        raw_body = json.dumps(valid_buy_payload, separators=(",", ":")).encode()
        signature = create_webhook_signature(valid_buy_payload, "test_secret_key")
        
        assert validator.verify_signature(raw_body, signature)
        assert not validator.verify_signature(raw_body, "invalid_signature")
    
    def test_bar_close_required(self, validator, valid_buy_payload):
        """Test rejection when bar_close is false."""
        valid_buy_payload["bar_close"] = False
        result = validator.validate_signal(valid_buy_payload)
        
        assert not result.is_valid
        assert "bar close" in result.rejection_reason.lower()
    
    def test_blocked_window_rejection(self, validator, valid_buy_payload):
        """Test rejection during blocked window (22:00-00:00 UTC)."""
        # Set time to 22:30 UTC
        valid_buy_payload["time"] = "2026-01-21T22:30:00Z"
        result = validator.validate_signal(valid_buy_payload)
        
        assert not result.is_valid
        assert "blocked" in result.rejection_reason.lower()
    
    def test_blocked_window_edge_start(self, validator, valid_buy_payload):
        """Test rejection at exact start of blocked window."""
        valid_buy_payload["time"] = "2026-01-21T22:00:00Z"
        result = validator.validate_signal(valid_buy_payload)
        
        assert not result.is_valid
    
    def test_blocked_window_edge_end(self, validator, valid_buy_payload):
        """Test acceptance at exact end of blocked window."""
        valid_buy_payload["time"] = "2026-01-21T00:00:00Z"
        result = validator.validate_signal(valid_buy_payload)
        
        # 00:00 is the end of the blocked window, should be accepted
        assert result.is_valid
    
    def test_allowed_time(self, validator, valid_buy_payload):
        """Test acceptance during allowed trading hours."""
        valid_buy_payload["time"] = "2026-01-21T12:00:00Z"  # Noon
        result = validator.validate_signal(valid_buy_payload)
        
        assert result.is_valid
    
    def test_daily_trade_limit(self, validator, valid_buy_payload):
        """Test rejection when daily trade limit reached."""
        result = validator.validate_signal(
            valid_buy_payload,
            current_trades_today=2  # Already at max
        )
        
        assert not result.is_valid
        assert "limit" in result.rejection_reason.lower()
    
    def test_adx_below_baseline(self, validator, valid_buy_payload):
        """Test rejection when ADX below baseline."""
        valid_buy_payload["adx"] = 15.0  # Below 20 baseline
        result = validator.validate_signal(valid_buy_payload)
        
        assert not result.is_valid
        assert "strength" in result.rejection_reason.lower() or "adx" in result.rejection_reason.lower()
    
    def test_braid_color_mismatch_buy(self, validator, valid_buy_payload):
        """Test rejection when braid color doesn't match BUY signal."""
        valid_buy_payload["braid_color"] = "red"  # Should be green for BUY
        result = validator.validate_signal(valid_buy_payload)
        
        assert not result.is_valid
        assert "braid" in result.rejection_reason.lower()
    
    def test_braid_color_mismatch_sell(self, validator, valid_sell_payload):
        """Test rejection when braid color doesn't match SELL signal."""
        valid_sell_payload["braid_color"] = "green"  # Should be red for SELL
        result = validator.validate_signal(valid_sell_payload)
        
        assert not result.is_valid
        assert "braid" in result.rejection_reason.lower()
    
    def test_duplicate_signal_rejection(self, validator, valid_buy_payload):
        """Test rejection of duplicate signals."""
        # First signal should pass
        result1 = validator.validate_signal(valid_buy_payload)
        assert result1.is_valid
        
        # Second identical signal should be rejected
        result2 = validator.validate_signal(valid_buy_payload)
        assert not result2.is_valid
        assert "duplicate" in result2.rejection_reason.lower()
    
    def test_price_tolerance_within_range(self, validator, valid_buy_payload):
        """Test price tolerance validation within acceptable range."""
        market_prices = {
            "coinbase": 50100.0,  # 0.2% difference
            "kraken": 49950.0     # 0.1% difference
        }
        
        result = validator.validate_signal(
            valid_buy_payload,
            market_prices=market_prices
        )
        
        assert result.is_valid
        # Should have no warnings about price deviation
    
    def test_price_tolerance_exceeded(self, validator, valid_buy_payload):
        """Test warning when price deviation exceeds tolerance."""
        market_prices = {
            "coinbase": 50500.0,  # 1% difference - exceeds 0.5% tolerance
        }
        
        result = validator.validate_signal(
            valid_buy_payload,
            market_prices=market_prices
        )
        
        # Should still be valid but with warning
        assert result.is_valid
        assert len(result.warnings) > 0
        assert any("deviation" in w.lower() for w in result.warnings)
    
    def test_invalid_signal_type(self, validator):
        """Test rejection of invalid signal type."""
        payload = {
            "signal": "INVALID",
            "close": 50000.0,
            "adx": 25.0,
            "braid_color": "green"
        }
        
        result = validator.validate_signal(payload)
        assert not result.is_valid
    
    def test_missing_required_fields(self, validator):
        """Test handling of missing required fields."""
        payload = {
            "signal": "BUY"
            # Missing close, adx, braid_color
        }
        
        result = validator.validate_signal(payload)
        assert not result.is_valid


class TestBlockedWindow:
    """Tests for blocked window time checking."""
    
    @pytest.fixture
    def validator(self):
        settings = Settings()
        settings.trading_window = TradingWindowConfig(
            blocked_start_hour=22,
            blocked_start_minute=0,
            blocked_end_hour=0,
            blocked_end_minute=0
        )
        return SignalValidator(settings)
    
    def test_times_in_blocked_window(self, validator):
        """Test various times that should be blocked."""
        blocked_times = [
            datetime(2026, 1, 21, 22, 0, tzinfo=timezone.utc),   # Start
            datetime(2026, 1, 21, 22, 30, tzinfo=timezone.utc),  # Middle
            datetime(2026, 1, 21, 23, 0, tzinfo=timezone.utc),   # 11 PM
            datetime(2026, 1, 21, 23, 59, tzinfo=timezone.utc),  # End of day
        ]
        
        for t in blocked_times:
            assert validator.is_in_blocked_window(t), f"{t} should be blocked"
    
    def test_times_outside_blocked_window(self, validator):
        """Test various times that should be allowed."""
        allowed_times = [
            datetime(2026, 1, 21, 0, 0, tzinfo=timezone.utc),    # Midnight (end)
            datetime(2026, 1, 21, 0, 1, tzinfo=timezone.utc),    # Just after midnight
            datetime(2026, 1, 21, 12, 0, tzinfo=timezone.utc),   # Noon
            datetime(2026, 1, 21, 21, 59, tzinfo=timezone.utc),  # Just before block
        ]
        
        for t in allowed_times:
            assert not validator.is_in_blocked_window(t), f"{t} should be allowed"


class TestWebhookSignature:
    """Tests for webhook signature creation."""
    
    def test_signature_creation(self):
        """Test that signature can be created and verified."""
        payload = {"signal": "BUY", "close": 50000.0}
        secret = "my_secret_key"
        
        signature = create_webhook_signature(payload, secret)
        
        assert signature is not None
        assert len(signature) == 64  # SHA256 hex digest length
    
    def test_signature_consistency(self):
        """Test that same payload produces same signature."""
        payload = {"signal": "BUY", "close": 50000.0}
        secret = "my_secret_key"
        
        sig1 = create_webhook_signature(payload, secret)
        sig2 = create_webhook_signature(payload, secret)
        
        assert sig1 == sig2
    
    def test_signature_differs_with_different_secret(self):
        """Test that different secrets produce different signatures."""
        payload = {"signal": "BUY", "close": 50000.0}
        
        sig1 = create_webhook_signature(payload, "secret1")
        sig2 = create_webhook_signature(payload, "secret2")
        
        assert sig1 != sig2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

"""
Pytest configuration and shared fixtures.
"""
import os
import sys
from pathlib import Path

import pytest

# Add src to path for imports
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

# Set test environment
os.environ["PAPER"] = "true"
os.environ["MODE"] = "independent"
os.environ["WEBHOOK_SECRET"] = "test_webhook_secret"
os.environ["LOG_LEVEL"] = "WARNING"


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests."""
    import asyncio
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def temp_database(tmp_path):
    """Create a temporary database for testing."""
    from src.services.database import Database
    db_path = tmp_path / "test_trading_bot.db"
    return Database(str(db_path))


@pytest.fixture
def mock_settings():
    """Create mock settings for testing."""
    from src.config import Settings, RiskConfig, TradingWindowConfig, StrengthIndicatorConfig
    
    settings = Settings()
    settings.paper_trading = True
    settings.webhook_secret = "test_secret"
    settings.risk = RiskConfig(
        stop_loss_pct=6.0,
        take_profit_pct=15.0,
        risk_pct_below_threshold=2.0,
        risk_pct_above_threshold=1.0,
        equity_threshold=100_000.0,
        max_slippage_pct=0.35
    )
    settings.trading_window = TradingWindowConfig(
        blocked_start_hour=22,
        blocked_start_minute=0,
        blocked_end_hour=0,
        blocked_end_minute=0,
        max_trades_per_day=2
    )
    settings.strength = StrengthIndicatorConfig(
        indicator_type="ADX",
        period=14,
        baseline=20.0,
        max_extension_pct=1.5
    )
    
    return settings


@pytest.fixture
def sample_ohlcv_data():
    """Create sample OHLCV data for testing."""
    from src.backtester.data import generate_sample_data
    return generate_sample_data(num_candles=100, start_price=50000.0)

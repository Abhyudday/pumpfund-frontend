"""
Unit tests for risk calculation module.
"""
import pytest
from src.config import Settings, RiskConfig
from src.utils.risk import RiskCalculator, calculate_position_size_simple


class TestRiskCalculator:
    """Tests for RiskCalculator class."""
    
    @pytest.fixture
    def settings(self):
        """Create settings with default risk config."""
        settings = Settings()
        settings.risk = RiskConfig(
            stop_loss_pct=6.0,
            take_profit_pct=15.0,
            risk_pct_below_threshold=2.0,
            risk_pct_above_threshold=1.0,
            equity_threshold=100_000.0
        )
        return settings
    
    @pytest.fixture
    def calculator(self, settings):
        """Create RiskCalculator instance."""
        return RiskCalculator(settings)
    
    def test_risk_percentage_below_threshold(self, calculator):
        """Test risk is 2% when equity below 100k."""
        equity = 50_000.0
        risk_pct = calculator.get_risk_percentage(equity)
        assert risk_pct == 0.02  # 2%
    
    def test_risk_percentage_at_threshold(self, calculator):
        """Test risk locks to 1% at 100k threshold."""
        equity = 100_000.0
        risk_pct = calculator.get_risk_percentage(equity)
        assert risk_pct == 0.01  # 1%
        assert calculator.is_risk_locked()
    
    def test_risk_percentage_above_threshold(self, calculator):
        """Test risk stays 1% above threshold."""
        equity = 150_000.0
        risk_pct = calculator.get_risk_percentage(equity)
        assert risk_pct == 0.01  # 1%
    
    def test_risk_lock_persists(self, calculator):
        """Test risk lock persists even when equity drops."""
        # First hit threshold
        calculator.get_risk_percentage(100_000.0)
        assert calculator.is_risk_locked()
        
        # Drop below threshold
        risk_pct = calculator.get_risk_percentage(50_000.0)
        assert risk_pct == 0.01  # Still locked at 1%
        assert calculator.is_risk_locked()
    
    def test_position_size_calculation(self, calculator):
        """Test position size calculation with exact formula."""
        equity = 10_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=True)
        
        # Expected: risk_amount = 10000 * 0.02 = 200
        # position_size = 200 / (0.06 * 50000) = 200 / 3000 = 0.0667
        expected_risk = 200.0
        expected_size = 200.0 / (0.06 * 50_000)
        
        assert result.is_valid
        assert abs(result.risk_amount - expected_risk) < 0.01
        assert abs(result.position_size - expected_size) < 0.0001
        assert result.risk_percentage == 0.02
    
    def test_position_size_with_1pct_risk(self, calculator):
        """Test position size with 1% risk (high equity)."""
        equity = 200_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=True)
        
        # Expected: risk_amount = 200000 * 0.01 = 2000
        # position_size = 2000 / (0.06 * 50000) = 2000 / 3000 = 0.6667
        expected_risk = 2000.0
        expected_size = 2000.0 / (0.06 * 50_000)
        
        assert result.is_valid
        assert abs(result.risk_amount - expected_risk) < 0.01
        assert abs(result.position_size - expected_size) < 0.0001
    
    def test_stop_loss_long(self, calculator):
        """Test stop loss calculation for long position."""
        equity = 10_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=True)
        
        # SL at 6% below entry
        expected_sl = 50_000 * (1 - 0.06)  # 47000
        assert abs(result.stop_loss_price - expected_sl) < 0.01
    
    def test_stop_loss_short(self, calculator):
        """Test stop loss calculation for short position."""
        equity = 10_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=False)
        
        # SL at 6% above entry for short
        expected_sl = 50_000 * (1 + 0.06)  # 53000
        assert abs(result.stop_loss_price - expected_sl) < 0.01
    
    def test_take_profit_long(self, calculator):
        """Test take profit calculation for long position."""
        equity = 10_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=True)
        
        # TP at 15% above entry
        expected_tp = 50_000 * (1 + 0.15)  # 57500
        assert abs(result.take_profit_price - expected_tp) < 0.01
    
    def test_take_profit_short(self, calculator):
        """Test take profit calculation for short position."""
        equity = 10_000.0
        entry_price = 50_000.0
        
        result = calculator.calculate_position_size(equity, entry_price, is_long=False)
        
        # TP at 15% below entry for short
        expected_tp = 50_000 * (1 - 0.15)  # 42500
        assert abs(result.take_profit_price - expected_tp) < 0.01
    
    def test_invalid_equity(self, calculator):
        """Test rejection with zero/negative equity."""
        result = calculator.calculate_position_size(0, 50_000.0)
        assert not result.is_valid
        assert "equity" in result.rejection_reason.lower()
        
        result = calculator.calculate_position_size(-1000, 50_000.0)
        assert not result.is_valid
    
    def test_invalid_entry_price(self, calculator):
        """Test rejection with zero/negative entry price."""
        result = calculator.calculate_position_size(10_000.0, 0)
        assert not result.is_valid
        assert "price" in result.rejection_reason.lower()
    
    def test_minimum_order_size(self, calculator):
        """Test rejection when position size below minimum."""
        # Very small equity leads to tiny position
        result = calculator.calculate_position_size(
            equity=10.0,
            entry_price=50_000.0,
            min_order_size=0.01  # Require at least 0.01 BTC
        )
        
        # Risk = 10 * 0.02 = 0.20
        # Size = 0.20 / (0.06 * 50000) = 0.0000667
        # This is below 0.01 minimum
        assert not result.is_valid
        assert "minimum" in result.rejection_reason.lower()
    
    def test_balance_validation(self, calculator):
        """Test balance validation."""
        is_valid, error = calculator.validate_balance(
            required_value=5000.0,
            available_balance=10000.0
        )
        assert is_valid
        assert error is None
        
        is_valid, error = calculator.validate_balance(
            required_value=10000.0,
            available_balance=5000.0
        )
        assert not is_valid
        assert "insufficient" in error.lower()
    
    def test_slippage_validation(self, settings, calculator):
        """Test slippage tolerance validation."""
        settings.risk.max_slippage_pct = 0.35
        
        # Within tolerance
        adjusted, is_valid, error = calculator.calculate_slippage_adjusted_size(
            position_size=0.1,
            expected_price=50_000.0,
            actual_price=50_100.0  # 0.2% slippage
        )
        assert is_valid
        
        # Exceeds tolerance
        adjusted, is_valid, error = calculator.calculate_slippage_adjusted_size(
            position_size=0.1,
            expected_price=50_000.0,
            actual_price=50_300.0  # 0.6% slippage
        )
        assert not is_valid
        assert "slippage" in error.lower()


class TestSimplePositionSize:
    """Tests for simple position size calculation function."""
    
    def test_default_parameters(self):
        """Test with default risk parameters."""
        size = calculate_position_size_simple(
            equity=10_000.0,
            entry_price=50_000.0
        )
        
        # risk = 10000 * 0.02 = 200
        # size = 200 / (0.06 * 50000) = 0.0667
        expected = 200.0 / (0.06 * 50_000)
        assert abs(size - expected) < 0.0001
    
    def test_custom_risk_percentage(self):
        """Test with custom risk percentage."""
        size = calculate_position_size_simple(
            equity=10_000.0,
            entry_price=50_000.0,
            risk_pct=1.0  # 1% risk
        )
        
        # risk = 10000 * 0.01 = 100
        # size = 100 / (0.06 * 50000) = 0.0333
        expected = 100.0 / (0.06 * 50_000)
        assert abs(size - expected) < 0.0001
    
    def test_custom_stop_loss(self):
        """Test with custom stop loss percentage."""
        size = calculate_position_size_simple(
            equity=10_000.0,
            entry_price=50_000.0,
            stop_loss_pct=3.0  # 3% SL
        )
        
        # risk = 10000 * 0.02 = 200
        # size = 200 / (0.03 * 50000) = 0.1333
        expected = 200.0 / (0.03 * 50_000)
        assert abs(size - expected) < 0.0001


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

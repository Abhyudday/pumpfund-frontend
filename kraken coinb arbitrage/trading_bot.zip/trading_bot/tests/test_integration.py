"""
Integration tests simulating webhook flow and order lifecycle.
"""
import asyncio
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.config import Settings
from src.models.signal import Signal, SignalType
from src.models.order import Order, OrderSide, OrderStatus, OrderType
from src.models.trade import Trade, TradeDirection, TradeStatus
from src.services.database import Database
from src.utils.validation import SignalValidator, create_webhook_signature


class TestWebhookIntegration:
    """Integration tests for webhook processing."""
    
    @pytest.fixture
    def settings(self):
        """Create test settings."""
        settings = Settings()
        settings.webhook_secret = "test_secret"
        settings.paper_trading = True
        return settings
    
    @pytest.fixture
    def db(self, tmp_path):
        """Create temporary database."""
        db_path = tmp_path / "test.db"
        return Database(str(db_path))
    
    @pytest.fixture
    def valid_webhook_payload(self):
        """Create valid webhook payload."""
        return {
            "signal": "BUY",
            "symbol": "BTCUSD",
            "time": datetime.now(timezone.utc).isoformat(),
            "close": 50000.0,
            "adx": 25.0,
            "braid_color": "green",
            "bar_close": True,
            "tf": "15m"
        }
    
    def test_full_webhook_validation_flow(self, settings, db, valid_webhook_payload):
        """Test complete webhook validation flow."""
        validator = SignalValidator(settings)
        
        # Create signature
        raw_body = json.dumps(valid_webhook_payload, separators=(",", ":")).encode()
        signature = create_webhook_signature(valid_webhook_payload, settings.webhook_secret)
        
        # Validate
        result = validator.validate_signal(
            payload=valid_webhook_payload,
            raw_body=raw_body,
            signature=signature,
            current_trades_today=0
        )
        
        assert result.is_valid
        assert result.signal is not None
        assert result.signal.signal_type == SignalType.BUY
        
        # Mark as processed and verify deduplication
        db.mark_signal_processed(result.signal.unique_id)
        assert db.is_signal_processed(result.signal.unique_id)
    
    def test_daily_trade_counter_flow(self, db):
        """Test daily trade counter operations."""
        # Initially should be 0
        assert db.get_daily_trade_count() == 0
        assert db.can_trade_today(2)
        
        # Increment
        new_count = db.increment_daily_trade_count("trade_1")
        assert new_count == 1
        assert db.can_trade_today(2)
        
        # Increment again
        new_count = db.increment_daily_trade_count("trade_2")
        assert new_count == 2
        assert not db.can_trade_today(2)  # At limit
    
    def test_trade_persistence(self, db):
        """Test trade save and retrieve."""
        trade = Trade(
            id="test_trade_1",
            exchange="coinbase",
            symbol="BTC/USD",
            direction=TradeDirection.LONG,
            status=TradeStatus.OPEN,
            entry_price=50000.0,
            entry_amount=0.1,
            entry_value=5000.0,
            stop_loss_price=47000.0,
            take_profit_price=57500.0
        )
        
        # Save
        db.save_trade(trade)
        
        # Retrieve
        retrieved = db.get_trade("test_trade_1")
        assert retrieved is not None
        assert retrieved.id == trade.id
        assert retrieved.entry_price == trade.entry_price
        assert retrieved.direction == TradeDirection.LONG
    
    def test_open_trades_query(self, db):
        """Test querying open trades."""
        # Create open trade
        open_trade = Trade(
            id="open_1",
            exchange="kraken",
            symbol="BTC/USD",
            direction=TradeDirection.LONG,
            status=TradeStatus.OPEN,
            entry_price=50000.0,
            entry_amount=0.1,
            entry_value=5000.0
        )
        db.save_trade(open_trade)
        
        # Create closed trade
        closed_trade = Trade(
            id="closed_1",
            exchange="coinbase",
            symbol="BTC/USD",
            direction=TradeDirection.LONG,
            status=TradeStatus.CLOSED,
            entry_price=50000.0,
            entry_amount=0.1,
            entry_value=5000.0,
            exit_price=52000.0,
            realized_pnl=200.0
        )
        db.save_trade(closed_trade)
        
        # Query open trades
        open_trades = db.get_open_trades()
        assert len(open_trades) == 1
        assert open_trades[0].id == "open_1"


class TestMockExchangeFlow:
    """Tests with mocked exchange connectors."""
    
    @pytest.fixture
    def mock_order_response(self):
        """Create mock order response."""
        return {
            "id": "order_123",
            "status": "closed",
            "filled": 0.1,
            "average": 50000.0,
            "fee": {"cost": 5.0, "currency": "USD"}
        }
    
    @pytest.mark.asyncio
    async def test_mock_market_order_execution(self, mock_order_response):
        """Test market order execution with mocked exchange."""
        from src.connectors.coinbase import CoinbaseConnector
        from src.config import Settings
        
        settings = Settings()
        connector = CoinbaseConnector(settings)
        
        # Mock the exchange
        connector._exchange = AsyncMock()
        connector._exchange.create_order = AsyncMock(return_value=mock_order_response)
        connector._exchange.fetch_order = AsyncMock(return_value=mock_order_response)
        
        # Execute order
        order = await connector.create_market_order(
            side=OrderSide.BUY,
            amount=0.1
        )
        
        assert order.status == OrderStatus.FILLED
        assert order.filled_amount == 0.1
        assert order.filled_price == 50000.0
    
    @pytest.mark.asyncio
    async def test_mock_order_failure_handling(self):
        """Test handling of order failures."""
        from src.connectors.coinbase import CoinbaseConnector
        from src.config import Settings
        import ccxt.async_support as ccxt_async
        
        settings = Settings()
        connector = CoinbaseConnector(settings)
        
        # Mock exchange to raise error
        connector._exchange = AsyncMock()
        connector._exchange.create_order = AsyncMock(
            side_effect=ccxt_async.InsufficientFunds("Not enough balance")
        )
        
        # Execute order - should handle gracefully
        order = await connector.create_market_order(
            side=OrderSide.BUY,
            amount=0.1
        )
        
        assert order.status == OrderStatus.FAILED
        assert "balance" in order.error_message.lower()


class TestBacktestIntegration:
    """Integration tests for backtester."""
    
    def test_backtest_with_sample_data(self):
        """Test backtest execution with generated data."""
        from src.backtester.data import generate_sample_data
        from src.backtester.engine import Backtester, BacktestConfig
        
        # Generate sample data
        data = generate_sample_data(num_candles=500, start_price=50000.0)
        
        # Configure backtest
        config = BacktestConfig(
            initial_equity=10000.0,
            stop_loss_pct=6.0,
            take_profit_pct=15.0,
            risk_pct=2.0
        )
        
        # Run backtest
        backtester = Backtester(config)
        metrics, trades = backtester.run(data)
        
        # Verify results
        assert metrics.initial_equity == 10000.0
        assert metrics.final_equity > 0  # Should still have some equity
        assert len(metrics.equity_curve) > 0
    
    def test_backtest_respects_trading_rules(self):
        """Test that backtest respects all trading rules."""
        from src.backtester.data import generate_sample_data
        from src.backtester.engine import Backtester, BacktestConfig
        
        data = generate_sample_data(num_candles=100)
        
        config = BacktestConfig(
            initial_equity=10000.0,
            max_trades_per_day=2,
            blocked_start_hour=22,
            blocked_end_hour=0
        )
        
        backtester = Backtester(config)
        metrics, trades = backtester.run(data)
        
        # Check no trades during blocked hours
        for trade in trades:
            if trade.entry_time:
                hour = trade.entry_time.hour
                assert not (hour >= 22 or hour < 0), f"Trade at blocked hour: {hour}"


class TestSignalToTradeFlow:
    """Test complete signal to trade execution flow."""
    
    @pytest.fixture
    def settings(self):
        settings = Settings()
        settings.paper_trading = True
        return settings
    
    def test_signal_parsing(self):
        """Test signal parsing from webhook payload."""
        payload = {
            "signal": "BUY",
            "symbol": "BTCUSD",
            "time": "2026-01-21T12:00:00Z",
            "close": 50000.0,
            "adx": 25.0,
            "braid_color": "green",
            "bar_close": True
        }
        
        signal = Signal.from_webhook_payload(payload)
        
        assert signal.signal_type == SignalType.BUY
        assert signal.close_price == 50000.0
        assert signal.adx == 25.0
        assert signal.validate_strength(20.0)
        assert signal.validate_braid_alignment()
    
    def test_trade_creation_from_signal(self, settings):
        """Test trade object creation from validated signal."""
        from src.utils.risk import RiskCalculator
        
        # Create signal
        signal = Signal(
            signal_type=SignalType.BUY,
            symbol="BTCUSD",
            timestamp=datetime.now(timezone.utc),
            close_price=50000.0,
            adx=25.0,
            braid_color="green"
        )
        
        # Calculate position
        calculator = RiskCalculator(settings)
        result = calculator.calculate_position_size(
            equity=10000.0,
            entry_price=signal.close_price,
            is_long=True
        )
        
        # Create trade
        trade = Trade(
            signal_id=signal.unique_id,
            exchange="coinbase",
            symbol="BTC/USD",
            direction=TradeDirection.LONG,
            status=TradeStatus.PENDING,
            entry_price=signal.close_price,
            entry_amount=result.position_size,
            entry_value=result.position_value,
            stop_loss_price=result.stop_loss_price,
            take_profit_price=result.take_profit_price
        )
        
        assert trade.signal_id == signal.unique_id
        assert trade.direction == TradeDirection.LONG
        assert trade.stop_loss_price == result.stop_loss_price
        assert trade.take_profit_price == result.take_profit_price


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
